# نصب کامفینگینو از GitHub با یک دستور

## 1) ساخت Repository

در GitHub یک repository بساز:

- Name: `komfingino`
- Visibility: بهتر است `Private` باشد، اما برای نصب با raw بدون توکن باید `Public` باشد.

## 2) آپلود سورس

فایل‌های پروژه را داخل repo بفرست. این فایل‌ها نباید داخل GitHub باشند:

- `config.php`
- `storage/bot.sqlite`
- `storage/*.db`
- `logs/`
- `.env`

فایل `.gitignore` داخل پروژه اضافه شده است.

## 3) دستور نصب روی سرور

اگر repo عمومی است:

```bash
curl -o install.sh -L https://raw.githubusercontent.com/USERNAME/komfingino/main/install.sh && sudo bash install.sh
```

اگر username تو `mahdiMGF2` است و repo اسمش `komfingino` است:

```bash
curl -o install.sh -L https://raw.githubusercontent.com/mahdiMGF2/komfingino/main/install.sh && sudo bash install.sh
```

## 4) موقع اجرای install.sh چه چیزهایی می‌پرسد؟

- دامنه یا ساب‌دامنه ربات، مثل `bot.example.com`
- آدرس repo، مثل `https://github.com/mahdiMGF2/komfingino.git`
- branch، معمولاً `main`
- مسیر نصب، پیش‌فرض `/var/www/komfingino`
- نصب Apache
- نصب SSL

## 5) ادامه نصب

بعد از اجرای اسکریپت، این آدرس را باز کن:

```text
https://YOUR-DOMAIN/install/
```

و اطلاعات ربات را وارد کن:

- Bot Token
- Admin Numeric ID
- Base URL
- رمز پنل
- درگاه‌ها
- کارت‌به‌کارت

بعد از نصب موفق، پوشه `install` را حذف کن.
