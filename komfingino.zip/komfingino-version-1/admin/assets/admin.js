let lastSvg = '';
async function openQR(text){
  const modal = document.getElementById('qrModal');
  const textarea = document.getElementById('qrText');
  const box = document.getElementById('qrBox');
  textarea.value = text || '';
  box.innerHTML = '<span>در حال ساخت QR...</span>';
  modal.style.display = 'grid';
  try {
    const body = new URLSearchParams();
    body.set('csrf', window.KOMFINGINO_CSRF || '');
    body.set('text', text || '');
    const res = await fetch('qr.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body});
    const svg = await res.text();
    if(!res.ok) throw new Error(svg || 'QR error');
    lastSvg = svg;
    box.innerHTML = svg;
  } catch(e) {
    box.innerHTML = '<span>خطا در ساخت QR: '+String(e.message || e)+'</span>';
  }
}
function closeQR(){document.getElementById('qrModal').style.display='none'}
function copyQRText(){navigator.clipboard.writeText(document.getElementById('qrText').value).then(()=>alert('کپی شد'))}
function downloadQR(){
  if(!lastSvg){alert('ابتدا QR بسازید');return}
  const blob = new Blob([lastSvg], {type:'image/svg+xml'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'configino-qr.svg';
  document.body.appendChild(a);
  a.click();
  a.remove();
}
document.addEventListener('keydown',e=>{if(e.key==='Escape') closeQR()});

function openAddConfigModal(){const el=document.getElementById('addConfigModal'); if(el) el.style.display='grid'}
function closeAddConfigModal(){const el=document.getElementById('addConfigModal'); if(el) el.style.display='none'}
