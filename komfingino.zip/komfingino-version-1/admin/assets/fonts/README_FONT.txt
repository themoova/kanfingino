فایل های فونت را در این پوشه قرار دهید:
YekanBakhFaNum-Regular.woff2
YekanBakhFaNum-SemiBold.woff2
YekanBakhFaNum-Bold.woff2
YekanBakhFaNum-ExtraBold.woff2

CSS پنل از همین مسیرها استفاده می کند.
