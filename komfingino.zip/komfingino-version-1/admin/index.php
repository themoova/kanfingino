<?php
$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => $secure,
    'httponly' => true,
    'samesite' => 'Lax',
]);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (empty($_SESSION['__init'])) {
    session_regenerate_id(true);
    $_SESSION['__init'] = 1;
}
require_once __DIR__ . '/../app/Helpers.php';
require_once __DIR__ . '/../app/Database.php';
require_once __DIR__ . '/../app/Crypto.php';
require_once __DIR__ . '/../app/Telegram.php';

$configPath = __DIR__ . '/../config.php';
if (!file_exists($configPath)) { http_response_code(503); exit('ابتدا نصب را تکمیل کنید.'); }
$config = require $configPath;
$db = new BotDatabase($config['db_path']);
$db->migrate();
$crypto = new BotCrypto($config['app_key']);
$tg = new TelegramClient($config['bot_token']);

function redirect_to(string $route): never {
    if (strpos($route, '&') !== false) {
        [$first, $rest] = explode('&', $route, 2);
        header('Location: ?r=' . rawurlencode($first) . '&' . $rest);
        exit;
    }
    header('Location: ?r=' . rawurlencode($route));
    exit;
}
function checked(bool $v): string { return $v ? 'checked' : ''; }
function selected($a, $b): string { return (string)$a === (string)$b ? 'selected' : ''; }
function csrf_input(): string { return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">'; }
function money($v): string { return number_format((int)$v) . ' تومان'; }
function badge(string $text, string $type = 'gray'): string { return '<span class="badge ' . h($type) . '">' . h($text) . '</span>'; }
function flash(): void {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash']; unset($_SESSION['flash']);
        echo '<div class="flash ' . h($f['type'] ?? 'success') . '">' . h($f['message'] ?? '') . '</div>';
    }
}
function set_flash(string $message, string $type='success'): void {
    $_SESSION['flash'] = ['message'=>$message,'type'=>$type];
}
function nav_link(string $route, string $label, string $icon, string $current): string {
    $active = $route === $current ? 'active' : '';
    return '<a class="' . $active . '" href="?r=' . h($route) . '"><span>' . h($label) . '</span><span class="meta">' . $icon . '</span></a>';
}
function page_title(string $route): string {
    $map = [
        'dashboard'=>'داشبورد','users'=>'کاربران','user'=>'پروفایل کاربر','categories'=>'فروشگاه','inventory'=>'موجودی','orders'=>'سفارش‌ها',
        'payments'=>'پرداخت‌ها','tickets'=>'تیکت‌ها','ticket'=>'چت تیکت','discounts'=>'کدهای تخفیف','gifts'=>'کدهای هدیه',
        'buttons'=>'مدیریت دکمه‌ها','texts'=>'مدیریت متن‌ها','channels'=>'کانال‌های جوین','logs'=>'لاگ امنیتی','settings'=>'تنظیمات'
    ];
    return $map[$route] ?? 'پنل مدیریت';
}
function layout_header(string $title, string $route): void {
    global $config;
    echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . ' | کامفینگینو</title><link rel="stylesheet" href="assets/admin.css"></head><body>';
    echo '<div class="app-shell">';
    echo '<aside class="sidebar">';
    echo '<div class="brand"><div class="brand-mark">✦</div><div><h1>کامفینگینو</h1><span>توسعه و کدنویسی توسط تمموا</span></div></div>';
    echo '<input class="search-box" placeholder="جستجوی سریع در پنل..." disabled>';
    echo '<div class="side-section"><div class="side-title">اصلی</div><nav class="nav">';
    echo nav_link('dashboard','داشبورد','🏠',$route);
    echo nav_link('users','کاربران','👤',$route);
    echo nav_link('categories','فروشگاه','🛒',$route);
    echo nav_link('inventory','انبار کانفیگ','🗂️',$route);
    echo nav_link('orders','سفارش‌ها','🧾',$route);
    echo nav_link('payments','پرداخت‌ها','💳',$route);
    echo '</nav></div>';
    echo '<div class="side-section"><div class="side-title">مدیریت</div><nav class="nav">';
    echo nav_link('tickets','تیکت‌ها','🎫',$route);
    echo nav_link('discounts','تخفیف‌ها','🏷️',$route);
    echo nav_link('gifts','هدیه‌ها','🎁',$route);
    echo nav_link('buttons','دکمه‌ها','🫧',$route);
    echo nav_link('texts','متن‌ها','✍️',$route);
    echo nav_link('channels','جوین اجباری','🔗',$route);
    echo nav_link('logs','امنیت','🛡️',$route);
    echo nav_link('settings','تنظیمات','⚙️',$route);
    echo '</nav></div>';
    echo '<div class="sidebar-footer">';
    echo '<a href="?r=settings">مرکز تنظیمات</a>';
    echo '<a href="?r=logout" class="logout-link">خروج از پنل</a>';
    echo '</div>';
    echo '</aside>';
    echo '<main class="main">';
    echo '<div class="topbar"><div class="breadcrumb"><span>خانه</span><span>/</span><strong>' . h($title) . '</strong></div>';
    echo '<div class="topbar-actions"><div class="icon-btn">🔔</div><div class="profile-chip"><div><strong>مدیر سیستم</strong><div class="muted">کامفینگینو</div></div><div class="avatar">TM</div></div></div></div>';
    echo '<div class="content-head"><div><h2>' . h($title) . '</h2><p>پنل سبک Brain Studio/Cleansheet با دکمه‌های شیشه‌ای، فونت یکان‌بخ و چیدمان اختصاصی پروژه.</p></div>';
    echo '<div class="actions-row"><a class="glass-btn btn-primary" href="?r=buttons">مدیریت دکمه‌ها</a><a class="glass-btn btn-secondary" href="?r=settings">تنظیمات</a></div></div>';
    flash();
}
function layout_footer(): void {
    echo '<div class="footer-note">کامفینگینو — نسخه رابط کاربری جدید | توسعه توسط تمموا</div>';
    echo '</main></div>';
    echo '<div class="qr-modal" id="qrModal"><div class="qr-dialog card"><div class="panel-head"><h3 class="panel-title">QR Code کانفیگ</h3><button class="glass-btn" type="button" onclick="closeQR()">بستن</button></div><div class="panel-body"><div class="qr-box" id="qrBox"></div><div class="field"><label>متن کانفیگ</label><textarea id="qrText" readonly></textarea></div><div class="actions-row" style="margin-top:14px"><button class="glass-btn btn-secondary" type="button" onclick="copyQRText()">کپی متن</button><button class="glass-btn btn-primary" type="button" onclick="downloadQR()">دانلود QR</button></div></div></div></div>';
    echo '<script>window.KOMFINGINO_CSRF=' . json_encode(csrf_token()) . ';</script><script src="assets/admin.js"></script></body></html>';
}
function login_view(string $error=''): never {
    global $config;
    echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>ورود پنل | کامفینگینو</title><link rel="stylesheet" href="assets/admin.css"></head><body>';
    echo '<div class="auth-shell">';
    echo '<div class="auth-brand"><div class="brand-mark">✦</div><div><h1 style="margin:0;font-size:28px">کامفینگینو</h1><span style="color:#808897">توسعه و کدنویسی توسط تمموا</span></div></div>';
    echo '<div class="login-card"><div class="login-icon">👤</div><h2>خوش برگشتی</h2><p>برای ورود به پنل مدیریت کامفینگینو رمز عبور را وارد کن.</p>';
    if ($error !== '') echo '<div class="flash error">' . h($error) . '</div>';
    echo '<form method="post" class="list-card">' . csrf_input() . '<input type="hidden" name="action" value="login">';
    echo '<div class="field"><label>نام کاربری</label><input class="input" name="username" placeholder="admin"></div>';
    echo '<div class="field"><label>رمز عبور</label><input class="input" type="password" name="password" required placeholder="رمز ورود پنل"></div>';
    echo '<button class="glass-btn btn-primary" type="submit" style="width:100%;margin-top:10px">ورود به پنل</button></form>';
    echo '<div class="login-footer"><span>© ' . date('Y') . ' کامفینگینو</span><span>فونت داخلی: Yekan Bakh</span></div></div></div></body></html>';
    exit;
}

if (($_GET['r'] ?? '') === 'logout') {
    $_SESSION = []; session_destroy(); redirect_to('login');
}

$loggedIn = !empty($_SESSION['admin_ok']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');
    if ($action === 'login') {
        csrf_check();
        $hash = (string)($config['panel_password_hash'] ?? '');
        $pass = (string)($_POST['password'] ?? '');
        if ($hash !== '' && password_verify($pass, $hash)) {
            $_SESSION['admin_ok'] = 1;
            session_regenerate_id(true);
            $db->logSecurity('admin', 'panel', 'panel_login');
            set_flash('ورود با موفقیت انجام شد.');
            redirect_to('dashboard');
        }
        $db->logSecurity('admin', 'panel', 'panel_login_failed');
        login_view('رمز عبور پنل صحیح نیست.');
    }
    if (!$loggedIn) login_view();
    csrf_check();
    try {
        switch ($action) {
            case 'settings_save':
                $bools = ['auth_required','gateway_zarinpal_enabled','gateway_zibal_enabled','gateway_card_enabled','referral_enabled'];
                foreach ($bools as $b) $db->setSetting($b, !empty($_POST[$b]) ? '1' : '0');
                $texts = ['force_channel','rate_window_seconds','rate_max_requests','rate_block_seconds','referral_reward_percent','referral_signup_bonus','card_info','support_text','help_text','zibal_merchant'];
                foreach ($texts as $k) $db->setSetting($k, trim((string)($_POST[$k] ?? '')));
                $db->logSecurity('admin','panel','settings_updated');
                set_flash('تنظیمات با موفقیت ذخیره شد.');
                redirect_to('settings');
            case 'group_save':
                $title = trim((string)($_POST['title'] ?? ''));
                $code = trim((string)($_POST['code'] ?? ''));
                if ($title === '') throw new RuntimeException('عنوان دسته الزامی است.');
                if ($code === '') $code = 'grp_' . substr(bin2hex(random_bytes(4)), 0, 8);
                $stmt = $db->pdo->prepare('INSERT INTO plan_groups(title,code,description,active,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,?,?)');
                $stmt->execute([$title, $code, trim((string)($_POST['description'] ?? '')), !empty($_POST['active']) ? 1 : 0, (int)($_POST['sort_order'] ?? 0), now_utc(), now_utc()]);
                $db->logSecurity('admin','panel','group_created','plan_group',$db->pdo->lastInsertId(),['code'=>$code]);
                set_flash('دسته جدید ساخته شد.');
                redirect_to('categories');
            case 'add_category':
                $stmt = $db->pdo->prepare('INSERT INTO categories(group_id,code,title,price,active,is_test,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)');
                $code = trim((string)($_POST['code'] ?? ''));
                $title = trim((string)($_POST['title'] ?? ''));
                $groupId = max(1, (int)($_POST['group_id'] ?? 1));
                if ($code === '' || $title === '') throw new RuntimeException('کد و عنوان پلن الزامی است.');
                $stmt->execute([$groupId, $code, $title, normalize_amount($_POST['price'] ?? 0), !empty($_POST['active']) ? 1 : 0, !empty($_POST['is_test']) ? 1 : 0, (int)($_POST['sort_order'] ?? 0), now_utc(), now_utc()]);
                $db->logSecurity('admin','panel','category_created','category',$db->pdo->lastInsertId(),['code'=>$code,'group_id'=>$groupId]);
                set_flash('پلن جدید ساخته شد.');
                redirect_to('categories');
            case 'add_inventory':
                $cat = (int)($_POST['category_id'] ?? 0);
                $configText = trim((string)($_POST['config_text'] ?? ''));
                $subLink = trim((string)($_POST['sub_link'] ?? ''));
                if ($cat <= 0 || $configText === '') throw new RuntimeException('دسته‌بندی و کانفیگ الزامی است.');
                $qrMode = in_array(($_POST['qr_mode'] ?? 'auto'), ['auto','manual','off'], true) ? (string)$_POST['qr_mode'] : 'auto';
                $qrFileId = trim((string)($_POST['qr_file_id'] ?? ''));
                $stmt = $db->pdo->prepare('INSERT INTO inventory(category_id,encrypted_config,encrypted_sub_link,note,qr_mode,qr_file_id,status,added_by,created_at,sold_at) VALUES(?,?,?,?,?,?,?,?,?,NULL)');
                $stmt->execute([$cat, $crypto->encrypt($configText), $subLink !== '' ? $crypto->encrypt($subLink) : null, trim((string)($_POST['note'] ?? '')), $qrMode, $qrFileId !== '' ? $qrFileId : null, 'available', (int)($config['admin_id'] ?? 0), now_utc()]);
                $db->logSecurity('admin','panel','inventory_added','inventory',$db->pdo->lastInsertId(),['category_id'=>$cat]);
                set_flash('کانفیگ به انبار اضافه شد.');
                redirect_to('inventory');
            case 'inventory_status':
                $id = (int)($_POST['inventory_id'] ?? 0);
                $status = (string)($_POST['status'] ?? 'available');
                if (!in_array($status, ['available','sold','disabled'], true)) $status = 'available';
                $stmt = $db->pdo->prepare('UPDATE inventory SET status=?, sold_at=CASE WHEN ?="sold" THEN COALESCE(sold_at, ?) ELSE sold_at END WHERE id=?');
                $stmt->execute([$status, $status, now_utc(), $id]);
                $db->logSecurity('admin','panel','inventory_status_changed','inventory',$id,['status'=>$status]);
                set_flash('وضعیت کانفیگ تغییر کرد.');
                redirect_to('inventory');
            case 'set_price':
                $id = (int)($_POST['category_id'] ?? 0);
                $stmt = $db->pdo->prepare('UPDATE categories SET price=?, updated_at=? WHERE id=?');
                $stmt->execute([normalize_amount($_POST['price'] ?? 0), now_utc(), $id]);
                $db->logSecurity('admin','panel','category_price_updated','category',$id,['price'=>normalize_amount($_POST['price'] ?? 0)]);
                set_flash('قیمت پلن بروزرسانی شد.');
                redirect_to('categories');
            case 'toggle_user_block':
                $uid = (int)($_POST['user_id'] ?? 0);
                $stmt = $db->pdo->prepare('UPDATE users SET is_blocked = CASE WHEN is_blocked=1 THEN 0 ELSE 1 END, updated_at=? WHERE id=?');
                $stmt->execute([now_utc(), $uid]);
                $db->logSecurity('admin','panel','user_block_toggled','user',$uid);
                set_flash('وضعیت کاربر تغییر کرد.');
                redirect_to('user&id=' . $uid);
            case 'user_balance':
                $uid = (int)($_POST['user_id'] ?? 0);
                $amount = normalize_amount($_POST['amount'] ?? 0);
                $op = (string)($_POST['op'] ?? 'add');
                if ($amount <= 0) throw new RuntimeException('مبلغ معتبر نیست.');
                $delta = $op === 'sub' ? -$amount : $amount;
                $stmt = $db->pdo->prepare('UPDATE users SET balance = MAX(balance + ?, 0), updated_at=? WHERE id=?');
                $stmt->execute([$delta, now_utc(), $uid]);
                $db->addUserTransaction($uid, $delta, $op === 'sub' ? 'admin_subtract' : 'admin_add', 'تنظیم موجودی توسط ادمین', 'admin');
                $db->logSecurity('admin','panel','user_balance_changed','user',$uid,['amount'=>$delta]);
                set_flash('موجودی کاربر بروزرسانی شد.');
                redirect_to('user&id=' . $uid);
            case 'create_discount':
                $code = trim((string)($_POST['code'] ?? ''));
                if ($code === '') throw new RuntimeException('کد تخفیف الزامی است.');
                $stmt = $db->pdo->prepare('INSERT INTO discount_codes(code,percent,max_discount,min_amount,usage_limit,used_count,active,expires_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)');
                $stmt->execute([$code, (int)($_POST['percent'] ?? 0), normalize_amount($_POST['max_discount'] ?? 0), normalize_amount($_POST['min_amount'] ?? 0), (int)($_POST['usage_limit'] ?? 0), 0, !empty($_POST['active']) ? 1 : 0, trim((string)($_POST['expires_at'] ?? '')) ?: null, now_utc(), now_utc()]);
                $db->logSecurity('admin','panel','discount_created','discount',$db->pdo->lastInsertId(),['code'=>$code]);
                set_flash('کد تخفیف ساخته شد.');
                redirect_to('discounts');
            case 'create_gift':
                $code = trim((string)($_POST['code'] ?? ''));
                if ($code === '') throw new RuntimeException('کد هدیه الزامی است.');
                $stmt = $db->pdo->prepare('INSERT INTO gift_codes(code,amount,used_by,used_at,created_at) VALUES(?,?,NULL,NULL,?)');
                $stmt->execute([$code, normalize_amount($_POST['amount'] ?? 0), now_utc()]);
                $db->logSecurity('admin','panel','gift_created','gift',$db->pdo->lastInsertId(),['code'=>$code]);
                set_flash('کد هدیه ساخته شد.');
                redirect_to('gifts');
            case 'ticket_reply':
                $ticketId = (int)($_POST['ticket_id'] ?? 0);
                $message = trim((string)($_POST['message'] ?? ''));
                if ($ticketId <= 0 || $message === '') throw new RuntimeException('پیام خالی است.');
                $stmt = $db->pdo->prepare('INSERT INTO ticket_messages(ticket_id,sender_type,sender_user_id,message,created_at) VALUES(?,?,?,?,?)');
                $stmt->execute([$ticketId,'admin',null,$message,now_utc()]);
                $stmt = $db->pdo->prepare('UPDATE tickets SET status=?, updated_at=?, last_message_at=? WHERE id=?');
                $stmt->execute(['open', now_utc(), now_utc(), $ticketId]);
                $q = $db->pdo->prepare('SELECT u.telegram_id FROM tickets t JOIN users u ON u.id=t.user_id WHERE t.id=?');
                $q->execute([$ticketId]);
                $tgId = (int)$q->fetchColumn();
                if ($tgId > 0) $tg->sendMessage($tgId, "📩 پاسخ جدید تیکت شما:\n" . $message);
                $db->logSecurity('admin','panel','ticket_replied','ticket',$ticketId);
                set_flash('پاسخ تیکت ارسال شد.');
                redirect_to('ticket&id=' . $ticketId);
            case 'ticket_status':
                $ticketId = (int)($_POST['ticket_id'] ?? 0);
                $status = trim((string)($_POST['status'] ?? 'open'));
                $stmt = $db->pdo->prepare('UPDATE tickets SET status=?, updated_at=? WHERE id=?');
                $stmt->execute([$status, now_utc(), $ticketId]);
                $db->logSecurity('admin','panel','ticket_status_changed','ticket',$ticketId,['status'=>$status]);
                set_flash('وضعیت تیکت تغییر کرد.');
                redirect_to('ticket&id=' . $ticketId);
            case 'card_payment_mark':
                $paymentId = (int)($_POST['payment_id'] ?? 0);
                $db->pdo->exec('BEGIN IMMEDIATE');
                $stmt = $db->pdo->prepare('SELECT * FROM payments WHERE id=?');
                $stmt->execute([$paymentId]);
                $p = $stmt->fetch();
                if (!$p) throw new RuntimeException('پرداخت یافت نشد.');
                if ($p['status'] !== 'paid') {
                    $stmt = $db->pdo->prepare("UPDATE payments SET status='paid', verified_at=?, ref_id=? WHERE id=?");
                    $stmt->execute([now_utc(), 'MANUAL-' . $paymentId, $paymentId]);
                    $stmt = $db->pdo->prepare('UPDATE users SET balance = balance + ?, updated_at=? WHERE id=?');
                    $stmt->execute([(int)$p['amount'], now_utc(), (int)$p['user_id']]);
                    $db->addUserTransaction((int)$p['user_id'], (int)$p['amount'], 'manual_payment', 'تایید دستی درگاه/کارت به کارت', 'admin');
                }
                $db->pdo->commit();
                $db->logSecurity('admin','panel','manual_payment_confirmed','payment',$paymentId);
                set_flash('پرداخت با موفقیت تایید شد.');
                redirect_to('payments');
            case 'template_save':
                $key = trim((string)($_POST['key'] ?? ''));
                $body = (string)($_POST['body'] ?? '');
                if ($key === '') throw new RuntimeException('کلید قالب نامعتبر است.');
                $stmt = $db->pdo->prepare('UPDATE message_templates SET body=?, updated_at=? WHERE key=?');
                $stmt->execute([$body, now_utc(), $key]);
                $db->logSecurity('admin','panel','message_template_updated','message_template',$key);
                set_flash('متن قالب ذخیره شد.');
                redirect_to('texts');
            case 'channel_save':
                $id = (int)($_POST['id'] ?? 0);
                $username = ltrim(trim((string)($_POST['username'] ?? '')), '@');
                $title = trim((string)($_POST['title'] ?? ''));
                $link = trim((string)($_POST['invite_link'] ?? ''));
                if ($username === '') throw new RuntimeException('یوزرنیم کانال الزامی است.');
                if ($title === '') $title = '@' . $username;
                if ($link === '') $link = 'https://t.me/' . $username;
                if ($id > 0) {
                    $stmt = $db->pdo->prepare('UPDATE forced_channels SET username=?, title=?, invite_link=?, active=?, sort_order=?, updated_at=? WHERE id=?');
                    $stmt->execute([$username,$title,$link,!empty($_POST['active'])?1:0,(int)($_POST['sort_order'] ?? 0),now_utc(),$id]);
                } else {
                    $stmt = $db->pdo->prepare('INSERT INTO forced_channels(username,title,invite_link,active,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,?,?)');
                    $stmt->execute([$username,$title,$link,!empty($_POST['active'])?1:0,(int)($_POST['sort_order'] ?? 0),now_utc(),now_utc()]);
                }
                $db->logSecurity('admin','panel','forced_channel_saved','forced_channel',$username);
                set_flash('کانال جوین اجباری ذخیره شد.');
                redirect_to('channels');
            case 'channel_delete':
                $id = (int)($_POST['id'] ?? 0);
                $stmt = $db->pdo->prepare('DELETE FROM forced_channels WHERE id=?');
                $stmt->execute([$id]);
                $db->logSecurity('admin','panel','forced_channel_deleted','forced_channel',$id);
                set_flash('کانال حذف شد.');
                redirect_to('channels');
            case 'channel_toggle':
                $id = (int)($_POST['id'] ?? 0);
                $stmt = $db->pdo->prepare('UPDATE forced_channels SET active=CASE WHEN active=1 THEN 0 ELSE 1 END, updated_at=? WHERE id=?');
                $stmt->execute([now_utc(),$id]);
                $db->logSecurity('admin','panel','forced_channel_toggled','forced_channel',$id);
                set_flash('وضعیت کانال تغییر کرد.');
                redirect_to('channels');
            case 'button_save':
                $id = (int)($_POST['id'] ?? 0);
                $label = trim((string)($_POST['label'] ?? ''));
                $scope = trim((string)($_POST['scope'] ?? 'user'));
                $actionType = trim((string)($_POST['action_type'] ?? 'text'));
                $actionValue = trim((string)($_POST['action_value'] ?? ''));
                if ($label === '') throw new RuntimeException('متن دکمه الزامی است.');
                if ($id > 0) {
                    $stmt = $db->pdo->prepare('UPDATE custom_buttons SET label=?, action_type=?, action_value=?, row_no=?, sort_order=?, scope=?, active=?, updated_at=? WHERE id=?');
                    $stmt->execute([$label, $actionType, $actionValue, (int)($_POST['row_no'] ?? 1), (int)($_POST['sort_order'] ?? 1), $scope, !empty($_POST['active']) ? 1 : 0, now_utc(), $id]);
                } else {
                    $stmt = $db->pdo->prepare('INSERT INTO custom_buttons(label,action_type,action_value,row_no,sort_order,scope,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)');
                    $stmt->execute([$label, $actionType, $actionValue, (int)($_POST['row_no'] ?? 1), (int)($_POST['sort_order'] ?? 1), $scope, !empty($_POST['active']) ? 1 : 0, now_utc(), now_utc()]);
                }
                $db->logSecurity('admin','panel','custom_button_saved');
                set_flash('دکمه با موفقیت ذخیره شد.');
                redirect_to('buttons');
            case 'button_delete':
                $id = (int)($_POST['id'] ?? 0);
                $stmt = $db->pdo->prepare('DELETE FROM custom_buttons WHERE id=?');
                $stmt->execute([$id]);
                $db->logSecurity('admin','panel','custom_button_deleted','custom_button',$id);
                set_flash('دکمه حذف شد.');
                redirect_to('buttons');
            case 'button_toggle':
                $id = (int)($_POST['id'] ?? 0);
                $stmt = $db->pdo->prepare('UPDATE custom_buttons SET active = CASE WHEN active=1 THEN 0 ELSE 1 END, updated_at=? WHERE id=?');
                $stmt->execute([now_utc(),$id]);
                $db->logSecurity('admin','panel','custom_button_toggled','custom_button',$id);
                set_flash('وضعیت دکمه تغییر کرد.');
                redirect_to('buttons');
        }
    } catch (Throwable $e) {
        if ($db->pdo->inTransaction()) $db->pdo->rollBack();
        set_flash($e->getMessage(), 'error');
        $back = (string)($_GET['r'] ?? 'dashboard');
        redirect_to($back);
    }
}

if (!$loggedIn) login_view();

$r = (string)($_GET['r'] ?? 'dashboard');
$editButton = null;
if ($r === 'buttons' && !empty($_GET['edit'])) {
    $stmt = $db->pdo->prepare('SELECT * FROM custom_buttons WHERE id=?');
    $stmt->execute([(int)$_GET['edit']]);
    $editButton = $stmt->fetch() ?: null;
}

if ($r === 'dashboard') {
    layout_header('داشبورد', $r);
    $stats = [
        'users' => (int)$db->pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(),
        'orders' => (int)$db->pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
        'stock' => (int)$db->pdo->query("SELECT COUNT(*) FROM inventory WHERE status='available'")->fetchColumn(),
        'tickets' => (int)$db->pdo->query("SELECT COUNT(*) FROM tickets WHERE status='open'")->fetchColumn(),
        'revenue' => (int)$db->pdo->query("SELECT COALESCE(SUM(final_amount),0) FROM orders")->fetchColumn(),
        'wallet' => (int)$db->pdo->query("SELECT COALESCE(SUM(balance),0) FROM users")->fetchColumn(),
        'payments' => (int)$db->pdo->query("SELECT COUNT(*) FROM payments WHERE status='paid'")->fetchColumn(),
        'referrals' => (int)$db->pdo->query("SELECT COUNT(*) FROM referrals")->fetchColumn(),
    ];
    echo '<div class="stats-grid">';
    echo '<div class="stat-card"><div class="row"><div><div class="icon-btn">👥</div><div class="stat-title">کل کاربران</div><div class="stat-value">' . number_format($stats['users']) . '</div></div><div class="kpi success">+ فعال</div></div></div>';
    echo '<div class="stat-card"><div class="row"><div><div class="icon-btn">🧾</div><div class="stat-title">کل سفارش‌ها</div><div class="stat-value">' . number_format($stats['orders']) . '</div></div><div class="kpi primary">فروش</div></div></div>';
    echo '<div class="stat-card"><div class="row"><div><div class="icon-btn">💰</div><div class="stat-title">درآمد کل</div><div class="stat-value">' . number_format($stats['revenue']) . '</div></div><div class="kpi success">تومان</div></div></div>';
    echo '<div class="stat-card"><div class="row"><div><div class="icon-btn">📦</div><div class="stat-title">موجودی آماده</div><div class="stat-value">' . number_format($stats['stock']) . '</div></div><div class="kpi warning">انبار</div></div></div>';
    echo '</div>';
    echo '<div class="layout-grid">';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">شاخص‌های سریع</h3><span class="muted">ویجت‌های سبک نمونه‌های ارسالی</span></div><div class="panel-body">';
    echo '<div class="metric-list">';
    $items = [
        ['پرداخت‌های موفق', $stats['payments'], min(100, $stats['payments'] ? 72 : 0), 'success'],
        ['تیکت‌های باز', $stats['tickets'], min(100, $stats['tickets'] * 10), 'warning'],
        ['مجموع موجودی کیف پول کاربران', money($stats['wallet']), 65, 'sky'],
        ['آیتم‌های رفرال', $stats['referrals'], 48, 'primary'],
    ];
    foreach ($items as $it) {
        echo '<div class="metric-item"><div><strong>' . h((string)$it[0]) . '</strong><div class="muted">' . h((string)$it[1]) . '</div></div><div style="min-width:180px;width:40%"><div class="progress"><span style="width:' . (int)$it[2] . '%"></span></div></div></div>';
    }
    echo '</div></div></section>';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">سرویس‌های برتر / هشدارها</h3><span>' . badge('UI جدید', 'primary') . '</span></div><div class="panel-body">';
    $topCats = $db->pdo->query('SELECT c.title, COUNT(o.id) cnt FROM categories c LEFT JOIN orders o ON o.category_id=c.id GROUP BY c.id ORDER BY cnt DESC LIMIT 5');
    echo '<div class="list-card">';
    foreach ($topCats as $row) echo '<div class="user-card"><strong>' . h($row['title']) . '</strong><div class="muted">' . number_format((int)$row['cnt']) . ' سفارش</div></div>';
    echo '<div class="user-card"><strong>امنیت پنل</strong><div class="muted">ضداسپم، لاگ امنیتی، سشن امن و CSRF فعال است.</div></div>';
    echo '</div></div></section>';
    echo '</div>';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">آخرین سفارش‌ها</h3><div class="actions-row"><a class="glass-btn" href="?r=orders">مشاهده همه</a></div></div><div class="panel-body"><div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>کاربر</th><th>پلن</th><th>مبلغ</th><th>وضعیت</th><th>زمان</th></tr></thead><tbody>';
    $stmt = $db->pdo->query('SELECT o.*,u.telegram_id,c.title FROM orders o JOIN users u ON u.id=o.user_id JOIN categories c ON c.id=o.category_id ORDER BY o.id DESC LIMIT 10');
    foreach ($stmt as $o) {
        echo '<tr><td>' . (int)$o['id'] . '</td><td>' . h($o['telegram_id']) . '</td><td>' . h($o['title']) . '</td><td>' . money($o['final_amount'] ?: $o['amount']) . '</td><td>' . badge($o['status'], $o['status']==='delivered' ? 'success' : 'warning') . '</td><td>' . h($o['created_at']) . '</td></tr>';
    }
    echo '</tbody></table></div></div></section>';
    layout_footer(); exit;
}

if ($r === 'users') {
    layout_header('کاربران', $r);
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">لیست کاربران</h3><div class="actions-row"><a class="glass-btn btn-secondary" href="?r=logs">لاگ امنیتی</a></div></div><div class="panel-body">';
    echo '<div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>تلگرام</th><th>یوزرنیم</th><th>نام</th><th>موجودی</th><th>احراز</th><th>وضعیت</th><th></th></tr></thead><tbody>';
    $stmt = $db->pdo->query('SELECT * FROM users ORDER BY id DESC LIMIT 300');
    foreach ($stmt as $u) {
        echo '<tr><td>' . (int)$u['id'] . '</td><td class="code">' . h($u['telegram_id']) . '</td><td>@' . h($u['username']) . '</td><td>' . h($u['first_name']) . '</td><td>' . money($u['balance']) . '</td><td>' . badge((int)$u['is_verified']===1 ? 'تایید شده' : 'نیازمند تایید', (int)$u['is_verified']===1 ? 'success' : 'warning') . '</td><td>' . badge((int)$u['is_blocked']===1 ? 'مسدود' : 'فعال', (int)$u['is_blocked']===1 ? 'danger' : 'success') . '</td><td><a class="glass-btn" href="?r=user&id=' . (int)$u['id'] . '">جزئیات</a></td></tr>';
    }
    echo '</tbody></table></div></div></section>';
    layout_footer(); exit;
}

if ($r === 'user') {
    $id = (int)($_GET['id'] ?? 0); $stmt=$db->pdo->prepare('SELECT * FROM users WHERE id=?'); $stmt->execute([$id]); $u=$stmt->fetch(); if(!$u) redirect_to('users');
    layout_header('پروفایل کاربر', $r);
    $ordersCount = (int)$db->pdo->query('SELECT COUNT(*) FROM orders WHERE user_id=' . $id)->fetchColumn();
    echo '<div class="stats-grid">';
    echo '<div class="stat-card"><div class="stat-title">تلگرام ID</div><div class="stat-value" style="font-size:28px">' . h($u['telegram_id']) . '</div></div>';
    echo '<div class="stat-card"><div class="stat-title">موجودی</div><div class="stat-value" style="font-size:28px">' . number_format($u['balance']) . '</div></div>';
    echo '<div class="stat-card"><div class="stat-title">سفارش‌ها</div><div class="stat-value" style="font-size:28px">' . number_format($ordersCount) . '</div></div>';
    echo '<div class="stat-card"><div class="stat-title">رفرال</div><div class="stat-value" style="font-size:28px">' . h($u['ref_code']) . '</div></div>';
    echo '</div>';
    echo '<div class="two-col">';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">اطلاعات کاربر</h3></div><div class="panel-body list-card">';
    echo '<div class="user-card"><strong>نام</strong><div class="muted">' . h($u['first_name']) . '</div></div>';
    echo '<div class="user-card"><strong>یوزرنیم</strong><div class="muted">@' . h($u['username']) . '</div></div>';
    echo '<div class="user-card"><strong>شماره</strong><div class="muted">' . h($u['phone']) . '</div></div>';
    echo '<div class="badges">' . badge((int)$u['is_verified']===1?'احراز شده':'احراز نشده', (int)$u['is_verified']===1?'success':'warning') . badge((int)$u['is_blocked']===1?'مسدود':'فعال', (int)$u['is_blocked']===1?'danger':'success') . '</div>';
    echo '<form method="post" class="actions-row">' . csrf_input() . '<input type="hidden" name="action" value="toggle_user_block"><input type="hidden" name="user_id" value="' . $id . '"><button class="glass-btn btn-danger" type="submit">مسدود/آزادسازی</button></form>';
    echo '</div></section>';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">تنظیم موجودی</h3></div><div class="panel-body"><form method="post" class="form-grid">' . csrf_input() . '<input type="hidden" name="action" value="user_balance"><input type="hidden" name="user_id" value="' . $id . '"><div class="field"><label>مبلغ</label><input class="input" name="amount" placeholder="مثلا 50000"></div><div class="field"><label>عملیات</label><select class="select" name="op"><option value="add">افزایش</option><option value="sub">کاهش</option></select></div><div class="field" style="align-self:end"><button class="glass-btn btn-primary" type="submit">ثبت تغییر</button></div></form></div></section>';
    echo '</div>';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">آخرین تراکنش‌ها</h3></div><div class="panel-body"><div class="table-wrap"><table class="table"><thead><tr><th>زمان</th><th>نوع</th><th>مبلغ</th><th>توضیح</th></tr></thead><tbody>';
    $stmt = $db->pdo->prepare('SELECT * FROM user_transactions WHERE user_id=? ORDER BY id DESC LIMIT 20'); $stmt->execute([$id]);
    foreach ($stmt as $t) echo '<tr><td>' . h($t['created_at']) . '</td><td>' . h($t['type']) . '</td><td>' . money($t['amount']) . '</td><td>' . h($t['reason']) . '</td></tr>';
    echo '</tbody></table></div></div></section>';
    layout_footer(); exit;
}

if ($r === 'categories') {
    layout_header('دسته‌ها و پلن‌ها', $r);
    echo '<div class="two-col">';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">افزودن دسته فروشگاه</h3></div><div class="panel-body"><form method="post" class="form-grid">' . csrf_input() . '<input type="hidden" name="action" value="group_save"><div class="field"><label>عنوان دسته</label><input class="input" name="title" placeholder="مثلا سرورهای اقتصادی"></div><div class="field"><label>کد دسته</label><input class="input" name="code" placeholder="eco"></div><div class="field"><label>توضیح</label><input class="input" name="description"></div><div class="field"><label>ترتیب</label><input class="input" name="sort_order" value="0"></div><label class="user-card"><input type="checkbox" name="active" checked> فعال</label><div class="field"><button class="glass-btn btn-primary" type="submit">ثبت دسته</button></div></form></div></section>';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">افزودن پلن داخل دسته</h3></div><div class="panel-body"><form method="post" class="form-grid">' . csrf_input() . '<input type="hidden" name="action" value="add_category"><div class="field"><label>دسته</label><select class="select" name="group_id">';
    foreach ($db->pdo->query('SELECT * FROM plan_groups ORDER BY sort_order,id') as $g) echo '<option value="' . (int)$g['id'] . '">' . h($g['title']) . '</option>';
    echo '</select></div><div class="field"><label>کد پلن</label><input class="input" name="code" placeholder="de_1m"></div><div class="field"><label>عنوان پلن</label><input class="input" name="title" placeholder="آلمان یک ماهه"></div><div class="field"><label>قیمت</label><input class="input" name="price" value="0"></div><div class="field"><label>مرتب‌سازی</label><input class="input" name="sort_order" value="0"></div><div class="field"><label><input type="checkbox" name="active" checked> فعال</label></div><div class="field"><label><input type="checkbox" name="is_test"> پلن تست</label></div><div class="field"><button class="glass-btn btn-primary" type="submit">ثبت پلن</button></div></form></div></section>';
    echo '</div>';
    echo '<section class="panel" style="margin-top:18px"><div class="panel-head"><h3 class="panel-title">لیست دسته‌ها و پلن‌ها</h3><span>' . badge('دسته‌بندی نامحدود', 'primary') . '</span></div><div class="panel-body"><div class="table-wrap"><table class="table"><thead><tr><th>دسته</th><th>پلن</th><th>کد</th><th>قیمت</th><th>موجود برای فروش</th><th>فروخته شده</th><th>وضعیت</th><th>به‌روزرسانی قیمت</th></tr></thead><tbody>';
    $stmt = $db->pdo->query("SELECT c.*, g.title AS group_title, SUM(CASE WHEN i.status='available' THEN 1 ELSE 0 END) AS available_count, SUM(CASE WHEN i.status='sold' THEN 1 ELSE 0 END) AS sold_count FROM categories c LEFT JOIN plan_groups g ON g.id=c.group_id LEFT JOIN inventory i ON i.category_id=c.id GROUP BY c.id ORDER BY g.sort_order,c.sort_order,c.id");
    foreach ($stmt as $c) {
        echo '<tr><td>' . h($c['group_title'] ?: 'عمومی') . '</td><td>' . h($c['title']) . '</td><td class="code">' . h($c['code']) . '</td><td>' . money($c['price']) . '</td><td>' . number_format((int)$c['available_count']) . '</td><td>' . number_format((int)$c['sold_count']) . '</td><td>' . badge((int)$c['active']===1 ? 'فعال' : 'غیرفعال', (int)$c['active']===1 ? 'success' : 'danger') . '</td><td><form method="post" class="actions-row">' . csrf_input() . '<input type="hidden" name="action" value="set_price"><input type="hidden" name="category_id" value="' . (int)$c['id'] . '"><input class="input" style="max-width:150px" name="price" value="' . (int)$c['price'] . '"><button class="glass-btn btn-secondary">ثبت</button></form></td></tr>';
    }
    echo '</tbody></table></div></div></section>';
    layout_footer(); exit;
}

if ($r === 'inventory') {
    layout_header('مدیریت کانفیگ‌ها', $r);
    $q = trim((string)($_GET['q'] ?? ''));
    $status = trim((string)($_GET['status'] ?? ''));
    $categoryId = (int)($_GET['category_id'] ?? 0);
    $where = []; $params = [];
    if ($status !== '' && in_array($status, ['available','sold','disabled'], true)) { $where[] = 'i.status=?'; $params[] = $status; }
    if ($categoryId > 0) { $where[] = 'i.category_id=?'; $params[] = $categoryId; }
    if ($q !== '') { $where[] = '(i.id LIKE ? OR c.title LIKE ? OR g.title LIKE ? OR i.note LIKE ?)'; $params = array_merge($params, ['%'.$q.'%','%'.$q.'%','%'.$q.'%','%'.$q.'%']); }
    $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
    $counts = $db->pdo->query("SELECT SUM(CASE WHEN status='available' THEN 1 ELSE 0 END) AS available_count, SUM(CASE WHEN status='sold' THEN 1 ELSE 0 END) AS sold_count, SUM(CASE WHEN status='disabled' THEN 1 ELSE 0 END) AS disabled_count, COUNT(*) AS total_count FROM inventory")->fetch();
    echo '<div class="stats-grid"><div class="stat-card"><div class="stat-title">کل کانفیگ‌ها</div><div class="stat-value">' . number_format((int)$counts['total_count']) . '</div></div><div class="stat-card"><div class="stat-title">موجود برای فروش</div><div class="stat-value">' . number_format((int)$counts['available_count']) . '</div></div><div class="stat-card"><div class="stat-title">فروخته شده</div><div class="stat-value">' . number_format((int)$counts['sold_count']) . '</div></div><div class="stat-card"><div class="stat-title">غیرفعال</div><div class="stat-value">' . number_format((int)$counts['disabled_count']) . '</div></div></div>';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">فیلتر و جستجو</h3><button class="glass-btn btn-primary" type="button" onclick="openAddConfigModal()">افزودن کانفیگ با پاپ‌آپ</button></div><div class="panel-body"><form method="get" class="form-grid-3"><input type="hidden" name="r" value="inventory"><div class="field"><label>جستجو</label><input class="input" name="q" value="' . h($q) . '" placeholder="شناسه، پلن، دسته، یادداشت"></div><div class="field"><label>وضعیت</label><select class="select" name="status"><option value="">همه</option><option value="available" ' . selected($status,'available') . '>موجود برای فروش</option><option value="sold" ' . selected($status,'sold') . '>فروخته‌شده</option><option value="disabled" ' . selected($status,'disabled') . '>غیرفعال</option></select></div><div class="field"><label>پلن</label><select class="select" name="category_id"><option value="0">همه پلن‌ها</option>';
    foreach ($db->pdo->query("SELECT c.id,c.title,g.title AS group_title FROM categories c LEFT JOIN plan_groups g ON g.id=c.group_id ORDER BY g.sort_order,c.sort_order,c.id") as $c) echo '<option value="' . (int)$c['id'] . '" ' . selected($categoryId,(int)$c['id']) . '>' . h(($c['group_title'] ?: 'عمومی') . ' / ' . $c['title']) . '</option>';
    echo '</select></div><div class="field"><button class="glass-btn btn-secondary">اعمال فیلتر</button></div></form></div></section>';
    echo '<div id="addConfigModal" class="qr-modal"><div class="qr-dialog card"><div class="panel-head"><h3 class="panel-title">افزودن کانفیگ جدید</h3><button class="glass-btn" type="button" onclick="closeAddConfigModal()">بستن</button></div><div class="panel-body"><form method="post" class="list-card">' . csrf_input() . '<input type="hidden" name="action" value="add_inventory"><div class="field"><label>پلن</label><select class="select" name="category_id">';
    foreach ($db->pdo->query("SELECT c.id,c.title,g.title AS group_title FROM categories c LEFT JOIN plan_groups g ON g.id=c.group_id ORDER BY g.sort_order,c.sort_order,c.id") as $c) echo '<option value="' . (int)$c['id'] . '">' . h(($c['group_title'] ?: 'عمومی') . ' / ' . $c['title']) . '</option>';
    echo '</select></div><div class="field"><label>کد کانفیگ V2Ray</label><textarea name="config_text" placeholder="vless://... یا vmess://..."></textarea></div><div class="field"><label>لینک ساب</label><input class="input" name="sub_link" placeholder="https://..."></div><div class="field"><label>حالت QR</label><select class="select" name="qr_mode"><option value="auto">ساخت اتومات از روی کد vless/vmess</option><option value="manual">دستی / file_id تلگرام</option><option value="off">غیرفعال</option></select></div><div class="field"><label>QR دستی / file_id</label><input class="input" name="qr_file_id" placeholder="در صورت داشتن file_id عکس QR"></div><div class="field"><label>یادداشت</label><input class="input" name="note"></div><button class="glass-btn btn-primary" type="submit">ذخیره کانفیگ</button></form></div></div></div>';
    echo '<section class="panel" style="margin-top:18px"><div class="panel-head"><h3 class="panel-title">کانفیگ‌ها</h3><span>' . badge('قابل فیلتر و تغییر وضعیت', 'sky') . '</span></div><div class="panel-body"><div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>دسته / پلن</th><th>وضعیت</th><th>QR</th><th>فروخته به</th><th>یادداشت</th><th>اقدام</th></tr></thead><tbody>';
    $sql = "SELECT i.*, c.title AS plan_title, g.title AS group_title, u.telegram_id AS sold_telegram FROM inventory i JOIN categories c ON c.id=i.category_id LEFT JOIN plan_groups g ON g.id=c.group_id LEFT JOIN users u ON u.id=i.sold_to $whereSql ORDER BY i.id DESC LIMIT 300";
    $stmt = $db->pdo->prepare($sql); $stmt->execute($params);
    foreach ($stmt as $item) {
        $cfg = $crypto->decrypt($item['encrypted_config']);
        echo '<tr><td>' . (int)$item['id'] . '</td><td>' . h(($item['group_title'] ?: 'عمومی') . ' / ' . $item['plan_title']) . '</td><td>' . badge($item['status'], $item['status']==='available' ? 'success' : ($item['status']==='sold' ? 'warning' : 'danger')) . '</td><td>' . h($item['qr_mode'] ?: 'auto') . '</td><td>' . h($item['sold_telegram'] ?: '-') . '</td><td>' . h($item['note']) . '</td><td><div class="actions-row"><button type="button" class="glass-btn btn-secondary" onclick="openQR(' . json_encode($cfg) . ')">QR/نمایش</button><form method="post">' . csrf_input() . '<input type="hidden" name="action" value="inventory_status"><input type="hidden" name="inventory_id" value="' . (int)$item['id'] . '"><select class="select" name="status"><option value="available">موجود</option><option value="sold">فروخته</option><option value="disabled">غیرفعال</option></select><button class="glass-btn">تغییر</button></form></div></td></tr>';
    }
    echo '</tbody></table></div></div></section>';
    layout_footer(); exit;
}

if ($r === 'orders') {
    layout_header('سفارش‌ها', $r);
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">سفارش‌های اخیر</h3></div><div class="panel-body"><div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>کاربر</th><th>پلن</th><th>مبلغ خام</th><th>تخفیف</th><th>مبلغ نهایی</th><th>وضعیت</th><th>تحویل</th></tr></thead><tbody>';
    $stmt = $db->pdo->query('SELECT o.*,u.telegram_id,c.title FROM orders o JOIN users u ON u.id=o.user_id JOIN categories c ON c.id=o.category_id ORDER BY o.id DESC LIMIT 300');
    foreach ($stmt as $o) echo '<tr><td>' . (int)$o['id'] . '</td><td>' . h($o['telegram_id']) . '</td><td>' . h($o['title']) . '</td><td>' . money($o['amount']) . '</td><td>' . money($o['discount_amount']) . '</td><td>' . money($o['final_amount'] ?: $o['amount']) . '</td><td>' . badge($o['status'], $o['status']==='delivered' ? 'success' : 'warning') . '</td><td>' . h($o['delivered_at']) . '</td></tr>';
    echo '</tbody></table></div></div></section>';
    layout_footer(); exit;
}

if ($r === 'payments') {
    layout_header('پرداخت‌ها', $r);
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">تراکنش‌ها و تایید دستی</h3><span>' . badge('زیبال + زرین‌پال', 'primary') . '</span></div><div class="panel-body"><div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>کاربر</th><th>مبلغ</th><th>درگاه</th><th>Authority/Track</th><th>وضعیت</th><th>زمان</th><th>اقدام</th></tr></thead><tbody>';
    $stmt = $db->pdo->query('SELECT p.*,u.telegram_id FROM payments p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT 200');
    foreach ($stmt as $p) {
        echo '<tr><td>' . (int)$p['id'] . '</td><td>' . h($p['telegram_id']) . '</td><td>' . money($p['amount']) . '</td><td>' . h($p['gateway']) . '</td><td class="code">' . h($p['authority'] ?: $p['ref_id']) . '</td><td>' . badge($p['status'], $p['status']==='paid' ? 'success' : ($p['status']==='cancelled' ? 'danger' : 'warning')) . '</td><td>' . h($p['created_at']) . '</td><td><form method="post">' . csrf_input() . '<input type="hidden" name="action" value="card_payment_mark"><input type="hidden" name="payment_id" value="' . (int)$p['id'] . '"><button class="glass-btn btn-success">تایید دستی</button></form></td></tr>';
    }
    echo '</tbody></table></div></div></section>';
    layout_footer(); exit;
}

if ($r === 'tickets') {
    layout_header('تیکت‌ها', $r);
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">فهرست تیکت‌ها</h3></div><div class="panel-body"><div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>کاربر</th><th>موضوع</th><th>وضعیت</th><th>آخرین پیام</th><th></th></tr></thead><tbody>';
    $stmt = $db->pdo->query('SELECT t.*,u.telegram_id,u.username,u.first_name FROM tickets t JOIN users u ON u.id=t.user_id ORDER BY t.last_message_at DESC LIMIT 200');
    foreach ($stmt as $t) echo '<tr><td>' . (int)$t['id'] . '</td><td>' . h($t['first_name']) . ' / ' . h($t['telegram_id']) . '</td><td>' . h($t['subject']) . '</td><td>' . badge($t['status'], $t['status']==='open' ? 'warning' : 'success') . '</td><td>' . h($t['last_message_at']) . '</td><td><a class="glass-btn" href="?r=ticket&id=' . (int)$t['id'] . '">چت</a></td></tr>';
    echo '</tbody></table></div></div></section>';
    layout_footer(); exit;
}

if ($r === 'ticket') {
    $id = (int)($_GET['id'] ?? 0); $stmt=$db->pdo->prepare('SELECT t.*,u.telegram_id,u.username,u.first_name FROM tickets t JOIN users u ON u.id=t.user_id WHERE t.id=?'); $stmt->execute([$id]); $t=$stmt->fetch(); if(!$t) redirect_to('tickets');
    layout_header('چت تیکت', $r);
    echo '<div class="two-col"><section class="panel"><div class="panel-head"><h3 class="panel-title">مشخصات تیکت</h3><span>' . badge($t['status'], $t['status']==='open' ? 'warning' : 'success') . '</span></div><div class="panel-body list-card"><div class="ticket-card"><strong>کاربر</strong><div class="muted">' . h($t['first_name']) . ' / ' . h($t['telegram_id']) . ' / @' . h($t['username']) . '</div></div><div class="ticket-card"><strong>موضوع</strong><div class="muted">' . h($t['subject']) . '</div></div><form method="post" class="actions-row">' . csrf_input() . '<input type="hidden" name="action" value="ticket_status"><input type="hidden" name="ticket_id" value="' . $id . '"><button class="glass-btn btn-success" name="status" value="closed">بستن تیکت</button><button class="glass-btn btn-secondary" name="status" value="open">بازکردن</button></form></div></section>';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">ارسال پاسخ</h3></div><div class="panel-body"><form method="post" class="list-card">' . csrf_input() . '<input type="hidden" name="action" value="ticket_reply"><input type="hidden" name="ticket_id" value="' . $id . '"><textarea name="message" placeholder="متن پاسخ ادمین..." required></textarea><button class="glass-btn btn-primary" type="submit">ارسال پاسخ</button></form></div></section></div>';
    echo '<section class="panel" style="margin-top:18px"><div class="panel-head"><h3 class="panel-title">گفت‌وگو</h3></div><div class="panel-body list-card">';
    $m=$db->pdo->prepare('SELECT * FROM ticket_messages WHERE ticket_id=? ORDER BY id'); $m->execute([$id]);
    foreach($m as $msg) echo '<div class="button-card"><div class="badges">' . badge($msg['sender_type'], $msg['sender_type']==='admin' ? 'primary' : 'sky') . '</div><div>' . nl2br(h($msg['message'])) . '</div><div class="muted">' . h($msg['created_at']) . '</div></div>';
    echo '</div></section>';
    layout_footer(); exit;
}

if ($r === 'discounts') {
    layout_header('کدهای تخفیف', $r);
    echo '<div class="two-col"><section class="panel"><div class="panel-head"><h3 class="panel-title">ساخت کد تخفیف</h3></div><div class="panel-body"><form method="post" class="form-grid">' . csrf_input() . '<input type="hidden" name="action" value="create_discount"><div class="field"><label>کد</label><input class="input" name="code"></div><div class="field"><label>درصد</label><input class="input" name="percent" value="10"></div><div class="field"><label>سقف تخفیف</label><input class="input" name="max_discount" value="0"></div><div class="field"><label>حداقل مبلغ</label><input class="input" name="min_amount" value="0"></div><div class="field"><label>تعداد استفاده</label><input class="input" name="usage_limit" value="0"></div><div class="field"><label>تاریخ انقضا</label><input class="input" name="expires_at" placeholder="2026-12-31 23:59:59"></div><div class="field"><label><input type="checkbox" name="active" checked> فعال باشد</label></div><div class="field"><button class="glass-btn btn-primary">ثبت کد</button></div></form></div></section>';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">کدهای ثبت‌شده</h3></div><div class="panel-body"><div class="table-wrap"><table class="table"><thead><tr><th>کد</th><th>درصد</th><th>استفاده</th><th>فعال</th><th>انقضا</th></tr></thead><tbody>';
    foreach ($db->pdo->query('SELECT * FROM discount_codes ORDER BY id DESC LIMIT 200') as $d) echo '<tr><td class="code">' . h($d['code']) . '</td><td>' . (int)$d['percent'] . '%</td><td>' . (int)$d['used_count'] . ' / ' . (int)$d['usage_limit'] . '</td><td>' . badge((int)$d['active']===1?'فعال':'غیرفعال',(int)$d['active']===1?'success':'danger') . '</td><td>' . h($d['expires_at']) . '</td></tr>';
    echo '</tbody></table></div></div></section></div>';
    layout_footer(); exit;
}

if ($r === 'gifts') {
    layout_header('کدهای هدیه', $r);
    echo '<div class="two-col"><section class="panel"><div class="panel-head"><h3 class="panel-title">ساخت کد هدیه</h3></div><div class="panel-body"><form method="post" class="form-grid">' . csrf_input() . '<input type="hidden" name="action" value="create_gift"><div class="field"><label>کد هدیه</label><input class="input" name="code"></div><div class="field"><label>مبلغ</label><input class="input" name="amount"></div><div class="field"><button class="glass-btn btn-primary">ثبت کد</button></div></form></div></section>';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">لیست هدیه‌ها</h3></div><div class="panel-body"><div class="table-wrap"><table class="table"><thead><tr><th>کد</th><th>مبلغ</th><th>استفاده شده توسط</th><th>زمان ثبت</th></tr></thead><tbody>';
    foreach ($db->pdo->query('SELECT g.*,u.telegram_id FROM gift_codes g LEFT JOIN users u ON u.id=g.used_by ORDER BY g.id DESC LIMIT 200') as $g) echo '<tr><td class="code">' . h($g['code']) . '</td><td>' . money($g['amount']) . '</td><td>' . h($g['telegram_id']) . '</td><td>' . h($g['created_at']) . '</td></tr>';
    echo '</tbody></table></div></div></section></div>';
    layout_footer(); exit;
}

if ($r === 'buttons') {
    layout_header('مدیریت دکمه‌ها', $r);
    echo '<div class="two-col"><section class="panel"><div class="panel-head"><h3 class="panel-title">' . ($editButton ? 'ویرایش دکمه' : 'افزودن دکمه جدید') . '</h3><span>' . badge('دکمه‌های شیشه‌ای', 'primary') . '</span></div><div class="panel-body"><form method="post" class="form-grid">' . csrf_input() . '<input type="hidden" name="action" value="button_save"><input type="hidden" name="id" value="' . (int)($editButton['id'] ?? 0) . '"><div class="field"><label>متن دکمه</label><input class="input" name="label" value="' . h($editButton['label'] ?? '') . '" placeholder="🎯 نمونه"></div><div class="field"><label>محدوده</label><select class="select" name="scope"><option value="user" ' . selected($editButton['scope'] ?? 'user', 'user') . '>کاربر</option><option value="admin" ' . selected($editButton['scope'] ?? 'user', 'admin') . '>ادمین</option><option value="all" ' . selected($editButton['scope'] ?? 'user', 'all') . '>همه</option></select></div><div class="field"><label>نوع عملکرد</label><select class="select" name="action_type"><option value="text" ' . selected($editButton['action_type'] ?? 'text', 'text') . '>ارسال متن آماده</option><option value="url" ' . selected($editButton['action_type'] ?? 'text', 'url') . '>ارسال لینک</option></select></div><div class="field"><label>مقدار عملکرد</label><input class="input" name="action_value" value="' . h($editButton['action_value'] ?? '') . '" placeholder="متن پاسخ یا لینک"></div><div class="field"><label>ردیف</label><input class="input" name="row_no" value="' . h($editButton['row_no'] ?? 1) . '"></div><div class="field"><label>ترتیب</label><input class="input" name="sort_order" value="' . h($editButton['sort_order'] ?? 1) . '"></div><div class="field"><label><input type="checkbox" name="active" ' . checked((int)($editButton['active'] ?? 1) === 1) . '> فعال</label></div><div class="field"><button class="glass-btn btn-primary" type="submit">ذخیره دکمه</button></div></form><div class="footer-note">دکمه‌ها در ربات به‌صورت کیبورد سفارشی اضافه می‌شوند. برای دکمه‌های تلگرام افکت شیشه‌ای از نظر بصری در پنل و مدیریت لحاظ شده است.</div></div></section>';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">دکمه‌های ثبت‌شده</h3></div><div class="panel-body list-card">';
    foreach ($db->pdo->query('SELECT * FROM custom_buttons ORDER BY row_no,sort_order,id') as $b) {
        echo '<div class="button-card"><div class="badges">' . badge($b['scope'], 'sky') . badge($b['action_type'], 'primary') . badge((int)$b['active']===1?'فعال':'غیرفعال',(int)$b['active']===1?'success':'danger') . '</div><strong>' . h($b['label']) . '</strong><div class="muted">' . h($b['action_value']) . '</div><div class="actions-row"><a class="glass-btn btn-secondary" href="?r=buttons&edit=' . (int)$b['id'] . '">ویرایش</a><form method="post">' . csrf_input() . '<input type="hidden" name="action" value="button_toggle"><input type="hidden" name="id" value="' . (int)$b['id'] . '"><button class="glass-btn">فعال/غیرفعال</button></form><form method="post">' . csrf_input() . '<input type="hidden" name="action" value="button_delete"><input type="hidden" name="id" value="' . (int)$b['id'] . '"><button class="glass-btn btn-danger">حذف</button></form></div></div>';
    }
    echo '</div></section></div>';
    layout_footer(); exit;
}


if ($r === 'texts') {
    layout_header('مدیریت متن‌ها', $r);
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">ادیتور قالب پیام‌ها</h3><span>' . badge('قابل تغییر از پنل و تلگرام', 'primary') . '</span></div><div class="panel-body"><div class="table-tools"><div class="muted">برای هر متن می‌توانید از متغیرها استفاده کنید. مثال: {first_name}، {balance}، {config}</div></div><div class="list-card">';
    $stmt = $db->pdo->query('SELECT * FROM message_templates ORDER BY group_name, sort_order, key');
    foreach ($stmt as $t) {
        echo '<form method="post" class="button-card">' . csrf_input() . '<input type="hidden" name="action" value="template_save"><input type="hidden" name="key" value="' . h($t['key']) . '">';
        echo '<div class="badges">' . badge($t['group_name'], 'sky') . badge($t['key'], 'primary') . '</div>';
        echo '<strong>' . h($t['title']) . '</strong><div class="muted">متغیرها: <span class="code">' . h($t['variables']) . '</span></div>';
        echo '<textarea name="body" style="min-height:150px">' . h($t['body']) . '</textarea>';
        echo '<button class="glass-btn btn-primary" type="submit">ذخیره این متن</button></form>';
    }
    echo '</div></div></section>';
    layout_footer(); exit;
}

if ($r === 'channels') {
    layout_header('کانال‌های جوین اجباری', $r);
    echo '<div class="two-col"><section class="panel"><div class="panel-head"><h3 class="panel-title">افزودن کانال</h3></div><div class="panel-body"><form method="post" class="list-card">' . csrf_input() . '<input type="hidden" name="action" value="channel_save"><div class="field"><label>یوزرنیم کانال</label><input class="input" name="username" placeholder="@mychannel"></div><div class="field"><label>عنوان نمایشی</label><input class="input" name="title" placeholder="کانال پشتیبانی"></div><div class="field"><label>لینک دعوت/عضویت</label><input class="input" name="invite_link" placeholder="https://t.me/mychannel"></div><div class="field"><label>ترتیب نمایش</label><input class="input" name="sort_order" value="0"></div><label class="user-card"><input type="checkbox" name="active" checked> فعال باشد</label><button class="glass-btn btn-primary">ثبت کانال</button></form><div class="footer-note">برای بررسی عضویت، ربات باید داخل کانال ادمین باشد.</div></div></section>';
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">کانال‌های فعال/غیرفعال</h3></div><div class="panel-body list-card">';
    foreach ($db->forcedChannels(false) as $ch) {
        echo '<div class="button-card"><div class="badges">' . badge((int)$ch['active']===1?'فعال':'غیرفعال',(int)$ch['active']===1?'success':'danger') . badge('@'.$ch['username'],'primary') . '</div><strong>' . h($ch['title']) . '</strong><div class="muted">' . h($ch['invite_link']) . '</div><form method="post" class="actions-row">' . csrf_input() . '<input type="hidden" name="id" value="' . (int)$ch['id'] . '"><button class="glass-btn btn-secondary" name="action" value="channel_toggle">فعال/غیرفعال</button><button class="glass-btn btn-danger" name="action" value="channel_delete">حذف</button></form></div>';
    }
    echo '</div></section></div>';
    layout_footer(); exit;
}

if ($r === 'logs') {
    layout_header('لاگ امنیتی', $r);
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">رویدادهای امنیتی</h3><span>' . badge('سخت‌گیرانه', 'danger') . '</span></div><div class="panel-body"><div class="table-wrap"><table class="table"><thead><tr><th>زمان</th><th>بازیگر</th><th>عملیات</th><th>موجودیت</th><th>IP</th><th>جزئیات</th></tr></thead><tbody>';
    foreach ($db->pdo->query('SELECT * FROM security_logs ORDER BY id DESC LIMIT 300') as $l) echo '<tr><td>' . h($l['created_at']) . '</td><td>' . h($l['actor_type']) . ' ' . h($l['actor_id']) . '</td><td>' . h($l['action']) . '</td><td>' . h($l['entity_type']) . ' #' . h($l['entity_id']) . '</td><td>' . h($l['ip']) . '</td><td><span class="code">' . h((string)$l['details']) . '</span></td></tr>';
    echo '</tbody></table></div></div></section>';
    layout_footer(); exit;
}

if ($r === 'settings') {
    layout_header('تنظیمات', $r);
    echo '<section class="panel"><div class="panel-head"><h3 class="panel-title">تنظیمات ربات و درگاه‌ها</h3><span>' . badge('Mirza style', 'primary') . '</span></div><div class="panel-body"><form method="post" class="list-card">' . csrf_input() . '<input type="hidden" name="action" value="settings_save">';
    echo '<div class="form-grid-3">';
    echo '<label class="user-card"><strong>احراز هویت شماره</strong><div class="muted">' . '<input type="checkbox" name="auth_required" ' . checked($db->setting('auth_required','0')==='1') . '> فعال' . '</div></label>';
    echo '<label class="user-card"><strong>زرین‌پال</strong><div class="muted"><input type="checkbox" name="gateway_zarinpal_enabled" ' . checked($db->setting('gateway_zarinpal_enabled','1')==='1') . '> فعال</div></label>';
    echo '<label class="user-card"><strong>زیبال</strong><div class="muted"><input type="checkbox" name="gateway_zibal_enabled" ' . checked($db->setting('gateway_zibal_enabled','0')==='1') . '> فعال</div></label>';
    echo '<label class="user-card"><strong>کارت به کارت</strong><div class="muted"><input type="checkbox" name="gateway_card_enabled" ' . checked($db->setting('gateway_card_enabled','1')==='1') . '> فعال</div></label>';
    echo '<label class="user-card"><strong>سیستم رفرال</strong><div class="muted"><input type="checkbox" name="referral_enabled" ' . checked($db->setting('referral_enabled','1')==='1') . '> فعال</div></label>';
    echo '</div>';
    echo '<div class="form-grid"><div class="field"><label>کانال اجباری</label><input class="input" name="force_channel" value="' . h($db->setting('force_channel','none')) . '"></div><div class="field"><label>مرچنت زیبال</label><input class="input" name="zibal_merchant" value="' . h($db->setting('zibal_merchant','')) . '" placeholder="zibal یا merchant واقعی"></div></div>';
    echo '<div class="form-grid-3"><div class="field"><label>بازه ضداسپم (ثانیه)</label><input class="input" name="rate_window_seconds" value="' . h($db->setting('rate_window_seconds','10')) . '"></div><div class="field"><label>حد مجاز درخواست</label><input class="input" name="rate_max_requests" value="' . h($db->setting('rate_max_requests','12')) . '"></div><div class="field"><label>زمان بلاک (ثانیه)</label><input class="input" name="rate_block_seconds" value="' . h($db->setting('rate_block_seconds','60')) . '"></div></div>';
    echo '<div class="form-grid"><div class="field"><label>درصد پاداش رفرال</label><input class="input" name="referral_reward_percent" value="' . h($db->setting('referral_reward_percent','10')) . '"></div><div class="field"><label>هدیه ثبت‌نام زیرمجموعه</label><input class="input" name="referral_signup_bonus" value="' . h($db->setting('referral_signup_bonus','0')) . '"></div></div>';
    echo '<div class="field"><label>متن کارت به کارت</label><textarea name="card_info">' . h($db->setting('card_info')) . '</textarea></div>';
    echo '<div class="field"><label>متن پشتیبانی</label><textarea name="support_text">' . h($db->setting('support_text')) . '</textarea></div>';
    echo '<div class="field"><label>آموزش اتصال</label><textarea name="help_text">' . h($db->setting('help_text')) . '</textarea></div>';
    echo '<button class="glass-btn btn-primary" type="submit">ذخیره تنظیمات</button></form></div></section>';
    layout_footer(); exit;
}

redirect_to('dashboard');
