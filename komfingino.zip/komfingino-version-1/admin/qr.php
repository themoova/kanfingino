<?php
require_once __DIR__ . '/../app/Helpers.php';
$configPath = __DIR__ . '/../config.php';
if (!file_exists($configPath)) { http_response_code(503); exit('Bot is not installed.'); }
session_start();
if (empty($_SESSION['admin_logged'])) { http_response_code(403); exit('Forbidden'); }
csrf_check();

$text = (string)($_POST['text'] ?? '');
if ($text === '') { http_response_code(422); exit('متن QR خالی است.'); }
if (strlen($text) > 2950) { http_response_code(422); exit('متن برای QR خیلی طولانی است.'); }

require_once __DIR__ . '/../app/vendor/qrcode.php';

try {
    $qr = new QRcode($text, 'L');
    $arr = $qr->getBarcodeArray();
    $matrix = $arr['bcode'] ?? [];
    $n = (int)($arr['num_rows'] ?? count($matrix));
    if ($n <= 0) { throw new RuntimeException('QR matrix is empty.'); }
    $scale = 8;
    $pad = 4;
    $size = ($n + ($pad * 2)) * $scale;
    header('Content-Type: image/svg+xml; charset=utf-8');
    echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '.$size.' '.$size.'" width="'.$size.'" height="'.$size.'" role="img" aria-label="Config QR">';
    echo '<rect width="100%" height="100%" fill="#ffffff"/>';
    echo '<g fill="#0f172a">';
    foreach ($matrix as $y => $row) {
        foreach ($row as $x => $v) {
            if ((int)$v === 1) {
                $rx = ($x + $pad) * $scale;
                $ry = ($y + $pad) * $scale;
                echo '<rect x="'.$rx.'" y="'.$ry.'" width="'.$scale.'" height="'.$scale.'"/>';
            }
        }
    }
    echo '</g></svg>';
} catch (Throwable $e) {
    http_response_code(500);
    echo 'QR generation failed: ' . h($e->getMessage());
}
