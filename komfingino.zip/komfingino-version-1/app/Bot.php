<?php
require_once __DIR__ . '/Helpers.php';
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Crypto.php';
require_once __DIR__ . '/Telegram.php';

class SecureV2RayBot {
    private string $root;
    private array $config;
    private BotDatabase $db;
    private BotCrypto $crypto;
    private TelegramClient $tg;

    public function __construct(string $root) {
        $this->root = rtrim($root, '/');
        $configPath = $this->root . '/config.php';
        if (!file_exists($configPath)) { http_response_code(503); echo 'Bot is not installed. Open /install first.'; exit; }
        $this->config = require $configPath;
        define('BOT_DEBUG', !empty($this->config['debug']));
        if (empty($this->config['installed']) || empty($this->config['bot_token'])) { http_response_code(503); echo 'Bot is not installed completely.'; exit; }
        $this->db = new BotDatabase($this->config['db_path']);
        $this->db->migrate();
        $this->crypto = new BotCrypto($this->config['app_key']);
        $this->tg = new TelegramClient($this->config['bot_token']);
    }

    public function handleWebhook(): void {
        $secret = (string)($this->config['webhook_secret'] ?? '');
        if ($secret !== '') {
            $header = $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '';
            if (!hash_equals($secret, $header)) { http_response_code(403); echo 'Forbidden'; return; }
        }
        $raw = file_get_contents('php://input');
        $update = json_decode($raw, true);
        if (!is_array($update)) { echo 'OK'; return; }
        if (isset($update['callback_query'])) $this->handleCallback($update['callback_query']);
        elseif (isset($update['message'])) $this->handleMessage($update['message']);
        echo 'OK';
    }

    private function handleMessage(array $message): void {
        $chatId = (int)($message['chat']['id'] ?? 0);
        $from = $message['from'] ?? [];
        $fromId = (int)($from['id'] ?? $chatId);
        $text = trim((string)($message['text'] ?? ''));
        if ($chatId === 0 || $fromId === 0) return;
        $user = $this->db->upsertUser($fromId, $from['username'] ?? null, $from['first_name'] ?? null);
        $refMsg = '';
        if (preg_match('/^\/start\s+(.+)$/u', $text, $m)) {
            $refMsg = $this->captureReferral($user, trim($m[1]));
            $user = $this->db->getUserById((int)$user['id']) ?: $user;
        }
        if (!$this->isAdmin($fromId) && !$this->checkRateLimit($fromId, $chatId)) return;
        if ((int)$user['is_blocked'] === 1 && !$this->isAdmin($fromId)) { $this->tg->sendMessage($chatId, $this->msg('blocked_user', ['telegram_id'=>$fromId])); return; }

        if (isset($message['contact'])) {
            $this->saveContact($chatId, $user, $message['contact']);
            return;
        }
        if ($this->isForcedJoinMissing($fromId)) { $this->sendForcedJoin($chatId); return; }
        if (!$this->isAdmin($fromId) && $this->db->setting('auth_required', '0') === '1' && (int)$user['is_verified'] !== 1) {
            $this->askPhone($chatId);
            return;
        }
        if ($text === '/start' || str_starts_with($text, '/start ') || $text === '🔘 بازگشت' || $text === '🔘 برگشت' || $text === '🏠 منوی اصلی') { $this->setStep($user['id'], 'none'); $this->showHome($chatId, $fromId, $refMsg); return; }
        if ($text === '/panel' && $this->isAdmin($fromId)) { $this->setStep($user['id'], 'none'); $this->showAdmin($chatId); return; }

        $step = (string)$user['step'];
        if ($step !== 'none' && $this->handleStep($chatId, $fromId, $user, $text, $message)) return;
        if ($this->handleCustomButton($chatId, $fromId, $user, $text)) return;

        switch ($text) {
            case '🚀 خرید سرویس جدید': $this->showBuyCategories($chatId); break;
            case '👨🏼‍💻 حساب کاربری': $this->showAccount($chatId, $user); break;
            case '📡 سرویس ها': $this->showUserOrders($chatId, $user['id']); break;
            case '💰 افزایش موجودی': $this->askCharge($chatId, $user['id']); break;
            case '🧬 آموزش اتصال': $this->tg->sendMessage($chatId, $this->msg('help_message')); break;
            case '👤 ارتباط با ما': $this->tg->sendMessage($chatId, $this->msg('support_message')); break;
            case '🎫 تیکت پشتیبانی': $this->showTickets($chatId, $user['id']); break;
            case '👥 رفرال گیری': $this->showReferral($chatId, $user); break;
            case '🎁 اکانت تست': $this->deliverTest($chatId, $user); break;
            case '[🎊] کد هدیه': $this->setStep($user['id'], 'gift'); $this->tg->sendMessage($chatId, $this->msg('gift_request'), ['reply_markup' => $this->backKeyboard()]); break;
            case '⚙️ پنل مدیریت': if ($this->isAdmin($fromId)) $this->showAdmin($chatId); break;
            case '⚙️ تنظیمات ربات': if ($this->isAdmin($fromId)) $this->showTelegramSettings($chatId); break;
            case '🧩 مدیریت متن‌ها': if ($this->isAdmin($fromId)) $this->showTelegramTemplates($chatId); break;
            case '🔗 کانال‌های جوین': if ($this->isAdmin($fromId)) $this->showTelegramForcedChannels($chatId); break;
            case '📊 آمار': if ($this->isAdmin($fromId)) $this->adminStats($chatId); break;
            case '➕ افزودن کانفیگ': if ($this->isAdmin($fromId)) $this->adminChooseCategory($chatId, 'add'); break;
            case '💵 تنظیم قیمت پلن': if ($this->isAdmin($fromId)) $this->adminChooseCategory($chatId, 'price'); break;
            case '📦 موجودی پلن‌ها': if ($this->isAdmin($fromId)) $this->adminStock($chatId); break;
            case '📢 پیام همگانی': if ($this->isAdmin($fromId)) { $this->setStep($user['id'], 'admin_broadcast'); $this->tg->sendMessage($chatId, 'متن پیام همگانی را ارسال کنید:', ['reply_markup' => $this->backKeyboard()]); } break;
            case '📝 تنظیم راهنما': if ($this->isAdmin($fromId)) { $this->setStep($user['id'], 'admin_help'); $this->tg->sendMessage($chatId, 'متن جدید آموزش اتصال را ارسال کنید:', ['reply_markup' => $this->backKeyboard()]); } break;
            case '🔐 تنظیم کانال اجباری': if ($this->isAdmin($fromId)) { $this->setStep($user['id'], 'admin_channel'); $this->tg->sendMessage($chatId, "یوزرنیم کانال را بدون @ بفرستید. برای غیرفعال کردن بنویسید: none", ['reply_markup' => $this->backKeyboard()]); } break;
            case '☎️ تنظیم پشتیبانی': if ($this->isAdmin($fromId)) { $this->setStep($user['id'], 'admin_support'); $this->tg->sendMessage($chatId, 'متن پشتیبانی را ارسال کنید:', ['reply_markup' => $this->backKeyboard()]); } break;
            case '💳 تنظیم کارت': if ($this->isAdmin($fromId)) { $this->setStep($user['id'], 'admin_card'); $this->tg->sendMessage($chatId, 'متن/شماره کارت و توضیحات کارت به کارت را ارسال کنید:', ['reply_markup' => $this->backKeyboard()]); } break;
            case '🎟 ساخت کد هدیه': if ($this->isAdmin($fromId)) { $this->setStep($user['id'], 'admin_gift_amount'); $this->tg->sendMessage($chatId, 'مبلغ کد هدیه را به تومان ارسال کنید:', ['reply_markup' => $this->backKeyboard()]); } break;
            default: $this->showHome($chatId, $fromId, $this->msg('main_menu_invalid'));
        }
    }

    private function handleCallback(array $cb): void {
        $id = (string)$cb['id'];
        $data = (string)($cb['data'] ?? '');
        $message = $cb['message'] ?? [];
        $chatId = (int)($message['chat']['id'] ?? 0);
        $messageId = (int)($message['message_id'] ?? 0);
        $from = $cb['from'] ?? [];
        $fromId = (int)($from['id'] ?? 0);
        $user = $this->db->upsertUser($fromId, $from['username'] ?? null, $from['first_name'] ?? null);
        $this->tg->answerCallback($id);
        if (!$this->isAdmin($fromId) && $this->db->setting('auth_required', '0') === '1' && (int)$user['is_verified'] !== 1) { $this->askPhone($chatId); return; }
        if ($data === 'home') { $this->showHome($chatId, $fromId); return; }
        if ($data === 'ticket_new') { $this->setStep($user['id'], 'ticket_subject'); $this->tg->sendMessage($chatId, $this->msg('ticket_subject_request'), ['reply_markup' => $this->backKeyboard()]); return; }
        if (str_starts_with($data, 'ticket_open:')) { $this->openTicketFromBot($chatId, $user['id'], (int)substr($data, 12)); return; }
        if (str_starts_with($data, 'ticket_close:')) { $this->closeTicketFromBot($chatId, $user['id'], (int)substr($data, 13)); return; }
        if (str_starts_with($data, 'buy:')) { $this->showCategoryConfirm($chatId, $messageId, (int)substr($data, 4)); return; }
        if (str_starts_with($data, 'confirm:')) { $this->purchaseCategory($chatId, $user, (int)substr($data, 8)); return; }
        if (str_starts_with($data, 'discount:')) { $catId=(int)substr($data, 9); $this->setStep($user['id'], 'discount_buy:' . $catId); $this->tg->sendMessage($chatId, $this->msg('discount_request'), ['reply_markup'=>$this->backKeyboard()]); return; }
        if (str_starts_with($data, 'buygrp:')) { $this->showBuyPlansInGroup($chatId, $messageId, (int)substr($data, 7)); return; }
        if ($this->isAdmin($fromId) && $this->handleAdminSettingCallback($chatId, $fromId, $user, $data)) return;
        if ($this->isAdmin($fromId) && str_starts_with($data, 'admin_add_group:')) { $this->showAdminPlanButtons($chatId, (int)substr($data, 16)); return; }
        if ($this->isAdmin($fromId) && str_starts_with($data, 'admin_add_plan:')) { $catId = (int)substr($data, 15); $this->setStep($user['id'], 'admin_add_config2:' . $catId); $cat = $this->getCategory($catId); $this->tg->sendMessage($chatId, 'مرحله ۳ از ۵\nکانفیگ مربوط به «' . h($cat['title'] ?? '') . '» را ارسال کنید:', ['reply_markup' => $this->backKeyboard()]); return; }
        if ($this->isAdmin($fromId) && str_starts_with($data, 'admin_add:')) { $catId = (int)substr($data, 10); $this->setStep($user['id'], 'admin_add_config2:' . $catId); $cat = $this->getCategory($catId); $this->tg->sendMessage($chatId, 'مرحله ۳ از ۵\nکانفیگ مربوط به «' . h($cat['title'] ?? '') . '» را ارسال کنید:', ['reply_markup' => $this->backKeyboard()]); return; }
        if ($this->isAdmin($fromId) && str_starts_with($data, 'admin_qr_auto:')) { $this->finishAdminInventoryFromState($chatId, $user['id'], 'auto', null); return; }
        if ($this->isAdmin($fromId) && str_starts_with($data, 'admin_qr_off:')) { $this->finishAdminInventoryFromState($chatId, $user['id'], 'off', null); return; }
        if ($this->isAdmin($fromId) && str_starts_with($data, 'admin_qr_manual:')) { $this->setStep($user['id'], 'admin_add_qr_file'); $this->tg->sendMessage($chatId, 'مرحله ۵ از ۵\nعکس QR را ارسال کنید یا file_id عکس را بفرستید:', ['reply_markup' => $this->backKeyboard()]); return; }
        if ($this->isAdmin($fromId) && str_starts_with($data, 'admin_price:')) { $catId = (int)substr($data, 12); $this->setStep($user['id'], 'admin_set_price:' . $catId); $cat = $this->getCategory($catId); $this->tg->sendMessage($chatId, 'قیمت جدید «' . h($cat['title'] ?? '') . '» را به تومان ارسال کنید:', ['reply_markup' => $this->backKeyboard()]); return; }
    }

    private function handleStep(int $chatId, int $fromId, array $user, string $text, array $message): bool {
        $step = (string)$user['step'];
        if ($text === '🔘 بازگشت' || $text === '🏠 منوی اصلی') { $this->setStep($user['id'], 'none'); $this->showHome($chatId, $fromId); return true; }
        if ($step === 'gift') { $this->redeemGift($chatId, $user, $text); return true; }
        if ($step === 'charge') { $amount = normalize_amount($text); if ($amount < 1000) { $this->tg->sendMessage($chatId, 'مبلغ معتبر نیست. حداقل ۱۰۰۰ تومان وارد کنید.'); return true; } $this->setStep($user['id'], 'none'); $this->sendPaymentLink($chatId, $fromId, $amount); return true; }
        if ($step === 'ticket_subject') { $subject = trim($text) ?: 'بدون موضوع'; $ticketId = $this->createTicket($user['id'], $subject, 'تیکت توسط کاربر ساخته شد.'); $this->setStep($user['id'], 'ticket_reply:' . $ticketId); $this->tg->sendMessage($chatId, "تیکت #$ticketId ساخته شد. پیام خود را بفرستید:", ['reply_markup' => $this->backKeyboard()]); return true; }
        if (str_starts_with($step, 'ticket_reply:')) { $ticketId=(int)substr($step,13); $this->addTicketMessage($ticketId, $user['id'], 'user', $text); $this->tg->sendMessage($chatId, 'پیام شما در تیکت ثبت شد. پاسخ ادمین همین‌جا ارسال می‌شود.', ['reply_markup' => $this->mainKeyboard($this->isAdmin($fromId))]); return true; }
        if (str_starts_with($step, 'discount_buy:')) { $catId=(int)substr($step,13); $this->setStep($user['id'],'none'); $this->purchaseCategory($chatId, $user, $catId, trim($text)); return true; }
        if ($this->isAdmin($fromId)) {
            if (str_starts_with($step, 'admin_add_config2:')) { $catId = (int)substr($step, 18); $this->setTempAddInventory($user['id'], ['category_id'=>$catId, 'config'=>$text]); $this->setStep($user['id'], 'admin_add_sub'); $this->tg->sendMessage($chatId, "مرحله ۴ از ۵\nلینک ساب را ارسال کنید. اگر ندارد بنویسید: none", ['reply_markup'=>$this->backKeyboard()]); return true; }
            if ($step === 'admin_add_sub') { $state=$this->getTempAddInventory($user['id']); $state['sub'] = strtolower(trim($text))==='none' ? '' : trim($text); $this->setTempAddInventory($user['id'], $state); $this->setStep($user['id'], 'admin_add_qr_mode'); $rows=[[['text'=>'ساخت QR اتومات از روی کانفیگ','callback_data'=>'admin_qr_auto:0']],[['text'=>'آپلود/ارسال QR دستی','callback_data'=>'admin_qr_manual:0']],[['text'=>'بدون QR','callback_data'=>'admin_qr_off:0']]]; $this->tg->sendMessage($chatId, "مرحله ۵ از ۵\nحالت QR را انتخاب کنید:", ['reply_markup'=>$this->inline($rows)]); return true; }
            if ($step === 'admin_add_qr_file') { $fileId=''; if (!empty($message['photo']) && is_array($message['photo'])) { $last=end($message['photo']); $fileId=(string)($last['file_id'] ?? ''); } if ($fileId==='') $fileId=trim($text); if ($fileId==='') { $this->tg->sendMessage($chatId, 'عکس یا file_id معتبر نیست. دوباره ارسال کنید.'); return true; } $this->finishAdminInventoryFromState($chatId, $user['id'], 'manual', $fileId); return true; }
            if (str_starts_with($step, 'admin_add_config:')) { $catId = (int)substr($step, 17); $this->addInventoryFromText($chatId, $user['id'], $catId, $text); return true; }
            if (str_starts_with($step, 'admin_set_price:')) { $catId = (int)substr($step, 16); $amount = normalize_amount($text); $stmt = $this->db->pdo->prepare('UPDATE categories SET price=?, updated_at=? WHERE id=?'); $stmt->execute([$amount, now_utc(), $catId]); $this->db->logSecurity('telegram_admin', $fromId, 'category_price_update', 'category', $catId, ['price'=>$amount]); $this->setStep($user['id'], 'none'); $this->tg->sendMessage($chatId, 'قیمت با موفقیت تنظیم شد: ' . number_format($amount) . ' تومان', ['reply_markup' => $this->adminKeyboard()]); return true; }
            if ($step === 'admin_broadcast') { $this->broadcast($chatId, $text); $this->setStep($user['id'], 'none'); return true; }
            if (str_starts_with($step, 'admin_edit_template:')) { $key = substr($step, 20); $stmt=$this->db->pdo->prepare('UPDATE message_templates SET body=?, updated_at=? WHERE key=?'); $stmt->execute([$text, now_utc(), $key]); $this->db->logSecurity('telegram_admin',$fromId,'template_update','message_template',$key); $this->setStep($user['id'],'none'); $this->tg->sendMessage($chatId, '✅ متن قالب ذخیره شد.', ['reply_markup'=>$this->adminKeyboard()]); return true; }
            if ($step === 'admin_add_forced_channel') { $this->addForcedChannelFromText($chatId, $user['id'], $text); return true; }
            if ($step === 'admin_help') { $this->db->setSetting('help_text', $text); $this->setStep($user['id'], 'none'); $this->tg->sendMessage($chatId, 'متن راهنما ذخیره شد.', ['reply_markup' => $this->adminKeyboard()]); return true; }
            if ($step === 'admin_channel') { $value = ltrim(trim($text), '@'); $this->db->setSetting('force_channel', $value === '' ? 'none' : $value); $this->setStep($user['id'], 'none'); $this->tg->sendMessage($chatId, 'تنظیم کانال اجباری ذخیره شد: ' . h($value), ['reply_markup' => $this->adminKeyboard()]); return true; }
            if ($step === 'admin_support') { $this->db->setSetting('support_text', $text); $this->setStep($user['id'], 'none'); $this->tg->sendMessage($chatId, 'متن پشتیبانی ذخیره شد.', ['reply_markup' => $this->adminKeyboard()]); return true; }
            if ($step === 'admin_card') { $this->db->setSetting('card_info', $text); $this->setStep($user['id'], 'none'); $this->tg->sendMessage($chatId, 'اطلاعات کارت ذخیره شد.', ['reply_markup' => $this->adminKeyboard()]); return true; }
            if ($step === 'admin_gift_amount') { $amount = normalize_amount($text); if ($amount <= 0) { $this->tg->sendMessage($chatId, 'مبلغ معتبر نیست.'); return true; } $code = 'GIFT-' . strtoupper(bin2hex(random_bytes(4))); $stmt = $this->db->pdo->prepare('INSERT INTO gift_codes(code, amount, created_at) VALUES(?,?,?)'); $stmt->execute([$code, $amount, now_utc()]); $this->db->logSecurity('telegram_admin', $fromId, 'gift_create', 'gift_code', $code, ['amount'=>$amount]); $this->setStep($user['id'], 'none'); $this->tg->sendMessage($chatId, "کد هدیه ساخته شد:\n<code>$code</code>\nمبلغ: " . number_format($amount) . ' تومان', ['reply_markup' => $this->adminKeyboard()]); return true; }
        }
        return false;
    }

    private function checkRateLimit(int $telegramId, int $chatId): bool {
        $now = time(); $window=(int)$this->db->setting('rate_window_seconds','10'); $max=(int)$this->db->setting('rate_max_requests','12'); $block=(int)$this->db->setting('rate_block_seconds','60');
        $stmt=$this->db->pdo->prepare('SELECT * FROM anti_spam WHERE telegram_id=?'); $stmt->execute([$telegramId]); $r=$stmt->fetch();
        if ($r && (int)$r['blocked_until'] > $now) { $this->tg->sendMessage($chatId, $this->msg('anti_spam_block', ['telegram_id'=>$telegramId])); return false; }
        if (!$r || $now - (int)$r['window_started_at'] > $window) { $stmt=$this->db->pdo->prepare('INSERT INTO anti_spam(telegram_id,window_started_at,request_count,blocked_until,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(telegram_id) DO UPDATE SET window_started_at=excluded.window_started_at, request_count=excluded.request_count, blocked_until=excluded.blocked_until, updated_at=excluded.updated_at'); $stmt->execute([$telegramId,$now,1,0,now_utc()]); return true; }
        $count=(int)$r['request_count']+1; $blockedUntil = $count>$max ? $now+$block : 0; $stmt=$this->db->pdo->prepare('UPDATE anti_spam SET request_count=?, blocked_until=?, updated_at=? WHERE telegram_id=?'); $stmt->execute([$count,$blockedUntil,now_utc(),$telegramId]);
        if ($blockedUntil) { $this->db->logSecurity('user',$telegramId,'anti_spam_block','user',$telegramId,['count'=>$count]); $this->tg->sendMessage($chatId, $this->msg('anti_spam_block', ['telegram_id'=>$telegramId])); return false; }
        return true;
    }

    private function saveContact(int $chatId, array $user, array $contact): void {
        $owner = (int)($contact['user_id'] ?? 0);
        if ($owner !== (int)$user['telegram_id']) { $this->tg->sendMessage($chatId, 'لطفاً فقط شماره خودتان را با دکمه ارسال شماره بفرستید.'); return; }
        $phone = normalize_phone($contact['phone_number'] ?? '');
        $stmt=$this->db->pdo->prepare('UPDATE users SET phone=?, is_verified=1, updated_at=? WHERE id=?'); $stmt->execute([$phone, now_utc(), $user['id']]);
        $this->db->logSecurity('user',$user['telegram_id'],'phone_verified','user',$user['id'],['phone'=>$phone]);
        $this->tg->sendMessage($chatId, $this->msg('auth_success', ['phone'=>$phone]), ['reply_markup'=>$this->mainKeyboard(false)]);
    }

    private function askPhone(int $chatId): void {
        $keyboard=json_encode(['keyboard'=>[[['text'=>'📱 ارسال شماره موبایل','request_contact'=>true]]],'resize_keyboard'=>true,'one_time_keyboard'=>true],JSON_UNESCAPED_UNICODE);
        $this->tg->sendMessage($chatId, $this->msg('auth_request'), ['reply_markup'=>$keyboard]);
    }

    private function captureReferral(array $user, string $payload): string {
        if ($this->db->setting('referral_enabled', '1') !== '1') {
            return '';
        }
        $code = trim($payload);
        if (str_starts_with($code, 'ref_')) {
            $code = substr($code, 4);
        }
        $code = strtoupper(preg_replace('/[^A-Z0-9]/i', '', $code));
        if ($code === '' || !empty($user['referred_by'])) {
            return '';
        }
        $referrer = $this->db->findUserByRefCode($code);
        if (!$referrer || (int)$referrer['id'] === (int)$user['id']) {
            return '';
        }
        if ($this->db->assignReferral((int)$user['id'], (int)$referrer['id'])) {
            $bonus = (int)$this->db->setting('referral_signup_bonus', '0');
            if ($bonus > 0) {
                $this->db->pdo->prepare('UPDATE users SET balance=balance+?, updated_at=? WHERE id=?')->execute([$bonus, now_utc(), (int)$referrer['id']]);
                $this->db->addUserTransaction((int)$referrer['id'], $bonus, 'referral_signup_bonus', 'هدیه ثبت‌نام زیرمجموعه', 'system');
            }
            $this->db->logSecurity('user', $user['telegram_id'], 'referral_registered', 'user', $user['id'], ['referrer_user_id'=>(int)$referrer['id'], 'code'=>$code]);
            return "✅ معرف شما ثبت شد. بعد از خرید، پاداش رفرال برای معرف محاسبه می‌شود.";
        }
        return '';
    }


    private function msg(string $key, array $vars = [], string $fallback = ''): string {
        $vars['bot_name'] = (string)($this->config['bot_name'] ?? 'کامفینگینو');
        return $this->db->renderTemplate($key, $vars, $fallback);
    }

    private function showTelegramSettings(int $chatId): void {
        $rows = [
            [['text'=>'احراز هویت: '.($this->db->setting('auth_required','0')==='1'?'فعال':'غیرفعال'), 'callback_data'=>'admin_toggle:auth_required']],
            [['text'=>'زرین‌پال: '.($this->db->setting('gateway_zarinpal_enabled','1')==='1'?'فعال':'غیرفعال'), 'callback_data'=>'admin_toggle:gateway_zarinpal_enabled']],
            [['text'=>'زیبال: '.($this->db->setting('gateway_zibal_enabled','0')==='1'?'فعال':'غیرفعال'), 'callback_data'=>'admin_toggle:gateway_zibal_enabled']],
            [['text'=>'کارت به کارت: '.($this->db->setting('gateway_card_enabled','1')==='1'?'فعال':'غیرفعال'), 'callback_data'=>'admin_toggle:gateway_card_enabled']],
            [['text'=>'رفرال: '.($this->db->setting('referral_enabled','1')==='1'?'فعال':'غیرفعال'), 'callback_data'=>'admin_toggle:referral_enabled']],
        ];
        $this->tg->sendMessage($chatId, "⚙️ تنظیمات سریع ربات\nبرای تغییر هر گزینه روی آن بزنید.", ['reply_markup'=>$this->inline($rows)]);
    }

    private function showTelegramTemplates(int $chatId): void {
        $stmt=$this->db->pdo->query('SELECT key,title,group_name FROM message_templates ORDER BY sort_order,key LIMIT 60');
        $rows=[];
        foreach($stmt as $t){ $rows[]=[['text'=>$t['title'].' | '.$t['group_name'], 'callback_data'=>'admin_tpl:'.$t['key']]]; }
        $this->tg->sendMessage($chatId, "🧩 مدیریت متن‌ها\nقالب موردنظر را انتخاب کنید و متن جدید را ارسال کنید.", ['reply_markup'=>$this->inline($rows)]);
    }

    private function showTelegramForcedChannels(int $chatId): void {
        $rows=[[['text'=>'➕ افزودن کانال جدید','callback_data'=>'admin_channel_add']]];
        foreach($this->db->forcedChannels(false) as $ch){
            $rows[]=[['text'=>($ch['active']?'✅ ':'❌ ').($ch['title'] ?: '@'.$ch['username']), 'callback_data'=>'admin_channel_toggle:'.$ch['id']], ['text'=>'حذف', 'callback_data'=>'admin_channel_del:'.$ch['id']]];
        }
        $this->tg->sendMessage($chatId, "🔗 کانال‌های جوین اجباری\nبرای افزودن، یوزرنیم کانال را بفرستید. ربات باید داخل کانال ادمین باشد.", ['reply_markup'=>$this->inline($rows)]);
    }

    private function handleAdminSettingCallback(int $chatId, int $fromId, array $user, string $data): bool {
        if (str_starts_with($data, 'admin_toggle:')) {
            $key = substr($data, 13);
            $allowed = ['auth_required','gateway_zarinpal_enabled','gateway_zibal_enabled','gateway_card_enabled','referral_enabled'];
            if (!in_array($key, $allowed, true)) return true;
            $new = $this->db->setting($key,'0') === '1' ? '0' : '1';
            $this->db->setSetting($key, $new);
            $this->db->logSecurity('telegram_admin',$fromId,'setting_toggle','setting',$key,['value'=>$new]);
            $this->tg->sendMessage($chatId, '✅ تنظیمات بروزرسانی شد.');
            $this->showTelegramSettings($chatId);
            return true;
        }
        if (str_starts_with($data, 'admin_tpl:')) {
            $key = substr($data, 10);
            $stmt=$this->db->pdo->prepare('SELECT * FROM message_templates WHERE key=?'); $stmt->execute([$key]); $tpl=$stmt->fetch();
            if(!$tpl){$this->tg->sendMessage($chatId,'قالب پیدا نشد.'); return true;}
            $this->setStep((int)$user['id'], 'admin_edit_template:' . $key);
            $this->tg->sendMessage($chatId, "متن جدید برای «".h($tpl['title'])."» را ارسال کنید.\n\nمتغیرها:\n".h($tpl['variables'])."\n\nمتن فعلی:\n".h($tpl['body']), ['reply_markup'=>$this->backKeyboard()]);
            return true;
        }
        if ($data === 'admin_channel_add') {
            $this->setStep((int)$user['id'], 'admin_add_forced_channel');
            $this->tg->sendMessage($chatId, "یوزرنیم کانال را بفرستید.\nمثال: @mychannel\nیا: @mychannel | عنوان | https://t.me/mychannel", ['reply_markup'=>$this->backKeyboard()]);
            return true;
        }
        if (str_starts_with($data, 'admin_channel_toggle:')) {
            $id=(int)substr($data,21); $stmt=$this->db->pdo->prepare('UPDATE forced_channels SET active=CASE WHEN active=1 THEN 0 ELSE 1 END, updated_at=? WHERE id=?'); $stmt->execute([now_utc(),$id]);
            $this->db->logSecurity('telegram_admin',$fromId,'forced_channel_toggle','forced_channel',$id);
            $this->showTelegramForcedChannels($chatId); return true;
        }
        if (str_starts_with($data, 'admin_channel_del:')) {
            $id=(int)substr($data,18); $stmt=$this->db->pdo->prepare('DELETE FROM forced_channels WHERE id=?'); $stmt->execute([$id]);
            $this->db->logSecurity('telegram_admin',$fromId,'forced_channel_delete','forced_channel',$id);
            $this->showTelegramForcedChannels($chatId); return true;
        }
        return false;
    }

    private function addForcedChannelFromText(int $chatId, int $adminUserId, string $text): void {
        $parts = array_map('trim', explode('|', $text));
        $username = ltrim($parts[0] ?? '', '@');
        if ($username === '') { $this->tg->sendMessage($chatId,'یوزرنیم کانال معتبر نیست.'); return; }
        $title = $parts[1] ?? ('@'.$username);
        $link = $parts[2] ?? ('https://t.me/'.$username);
        $stmt=$this->db->pdo->prepare('INSERT INTO forced_channels(username,title,invite_link,active,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(username) DO UPDATE SET title=excluded.title, invite_link=excluded.invite_link, active=1, updated_at=excluded.updated_at');
        $stmt->execute([$username,$title,$link,1,0,now_utc(),now_utc()]);
        $this->db->logSecurity('telegram_admin',$adminUserId,'forced_channel_save','forced_channel',$username);
        $this->setStep($adminUserId,'none');
        $this->tg->sendMessage($chatId,'✅ کانال جوین اجباری ذخیره شد.', ['reply_markup'=>$this->adminKeyboard()]);
    }

    private function showHome(int $chatId, int $fromId, string $prefix = ''): void { $user=$this->db->getUserByTelegramId($fromId) ?: []; $body=$this->msg('welcome_message', ['first_name'=>$user['first_name'] ?? '', 'telegram_id'=>$fromId, 'username'=>$user['username'] ?? '', 'balance'=>number_format((int)($user['balance'] ?? 0))]); $text = ($prefix ? $prefix . "\n\n" : '') . $body; $this->tg->sendMessage($chatId, $text, ['reply_markup' => $this->mainKeyboard($this->isAdmin($fromId))]); }
    private function mainKeyboard(bool $admin = false): string { $rows = [[['text'=>'🚀 خرید سرویس جدید']],[['text'=>'👨🏼‍💻 حساب کاربری'],['text'=>'[🎊] کد هدیه'],['text'=>'📡 سرویس ها']],[['text'=>'💰 افزایش موجودی'],['text'=>'🧬 آموزش اتصال']],[['text'=>'🎫 تیکت پشتیبانی'],['text'=>'👥 رفرال گیری'],['text'=>'🎁 اکانت تست']],[['text'=>'👤 ارتباط با ما']]]; foreach ($this->getCustomButtonRows($admin) as $row) { $rows[] = $row; } if ($admin) $rows[]=[['text'=>'⚙️ پنل مدیریت']]; return json_encode(['keyboard'=>$rows,'resize_keyboard'=>true],JSON_UNESCAPED_UNICODE); }
    private function adminKeyboard(): string { return json_encode(['keyboard'=>[[['text'=>'📊 آمار'],['text'=>'📦 موجودی پلن‌ها']],[['text'=>'➕ افزودن کانفیگ'],['text'=>'💵 تنظیم قیمت پلن']],[['text'=>'⚙️ تنظیمات ربات'],['text'=>'🧩 مدیریت متن‌ها']],[['text'=>'🔗 کانال‌های جوین'],['text'=>'📢 پیام همگانی']],[['text'=>'📝 تنظیم راهنما'],['text'=>'☎️ تنظیم پشتیبانی'],['text'=>'💳 تنظیم کارت']],[['text'=>'🎟 ساخت کد هدیه'],['text'=>'🏠 منوی اصلی']]],'resize_keyboard'=>true],JSON_UNESCAPED_UNICODE); }

    private function getCustomButtonRows(bool $admin = false): array {
        $scopes = $admin ? ['all', 'admin'] : ['all', 'user'];
        $in = implode(',', array_fill(0, count($scopes), '?'));
        $stmt = $this->db->pdo->prepare("SELECT * FROM custom_buttons WHERE active=1 AND scope IN ($in) ORDER BY row_no, sort_order, id");
        $stmt->execute($scopes);
        $rows = [];
        foreach ($stmt->fetchAll() as $btn) {
            $rowNo = max(1, (int)$btn['row_no']);
            if (!isset($rows[$rowNo])) $rows[$rowNo] = [];
            $rows[$rowNo][] = ['text' => (string)$btn['label']];
        }
        ksort($rows);
        return array_values($rows);
    }

    private function handleCustomButton(int $chatId, int $fromId, array $user, string $text): bool {
        if ($text === '') return false;
        $scopes = $this->isAdmin($fromId) ? ['all', 'admin'] : ['all', 'user'];
        $in = implode(',', array_fill(0, count($scopes), '?'));
        $params = array_merge([$text], $scopes);
        $stmt = $this->db->pdo->prepare("SELECT * FROM custom_buttons WHERE label=? AND active=1 AND scope IN ($in) ORDER BY id DESC LIMIT 1");
        $stmt->execute($params);
        $btn = $stmt->fetch();
        if (!$btn) return false;
        $value = trim((string)($btn['action_value'] ?? ''));
        if ((string)$btn['action_type'] === 'url') {
            $this->tg->sendMessage($chatId, $value !== '' ? $value : 'لینکی برای این دکمه ثبت نشده است.');
            return true;
        }
        $this->tg->sendMessage($chatId, $value !== '' ? $value : 'برای این دکمه هنوز پاسخی تنظیم نشده است.');
        return true;
    }
    private function backKeyboard(): string { return json_encode(['keyboard'=>[[['text'=>'🏠 منوی اصلی']]],'resize_keyboard'=>true],JSON_UNESCAPED_UNICODE); }
    private function inline(array $rows): string { return json_encode(['inline_keyboard'=>$rows],JSON_UNESCAPED_UNICODE); }
    private function showAdmin(int $chatId): void { $url=rtrim((string)$this->config['base_url'],'/') . '/admin/'; $this->tg->sendMessage($chatId, $this->msg('admin_panel_message', ['panel_url'=>$url]), ['reply_markup'=>$this->adminKeyboard()]); }
    private function isAdmin(int $telegramId): bool { return $telegramId > 0 && $telegramId === (int)$this->config['admin_id']; }
    private function setStep(int $userId, string $step): void { $stmt=$this->db->pdo->prepare('UPDATE users SET step=?, updated_at=? WHERE id=?'); $stmt->execute([$step, now_utc(), $userId]); }
    private function isForcedJoinMissing(int $telegramId): bool { return count($this->missingForcedChannels($telegramId)) > 0; }
    private function missingForcedChannels(int $telegramId): array { $missing=[]; foreach($this->db->forcedChannels(true) as $ch){ $username='@'.ltrim((string)$ch['username'],'@'); $res=$this->tg->getChatMember($username,$telegramId); $status=$res['result']['status']??''; if(!in_array($status,['creator','administrator','member'],true)) $missing[]=$ch; } return $missing; }
    private function sendForcedJoin(int $chatId): void { $channels=$this->db->forcedChannels(true); $lines=[]; foreach($channels as $ch){ $title=trim((string)($ch['title'] ?: ('@'.ltrim((string)$ch['username'],'@')))); $link=trim((string)($ch['invite_link'] ?: ('https://t.me/'.ltrim((string)$ch['username'],'@')))); $lines[]='• '.$title.' - '.$link; } $this->tg->sendMessage($chatId,$this->msg('forced_join',['channels'=>implode("\n",$lines)])); }
    private function getCategory(int $id): ?array { $stmt=$this->db->pdo->prepare('SELECT * FROM categories WHERE id=?'); $stmt->execute([$id]); $row=$stmt->fetch(); return $row ?: null; }

    private function showBuyCategories(int $chatId): void { $stmt=$this->db->pdo->query("SELECT g.*, COUNT(c.id) AS plan_count, SUM(CASE WHEN i.status='available' THEN 1 ELSE 0 END) AS stock FROM plan_groups g JOIN categories c ON c.group_id=g.id AND c.active=1 AND c.is_test=0 LEFT JOIN inventory i ON i.category_id=c.id AND i.status='available' WHERE g.active=1 GROUP BY g.id ORDER BY g.sort_order,g.id"); $rows=[]; foreach($stmt as $g){ $rows[]=[['text'=>$g['title'].' | پلن '.(int)$g['plan_count'].' | موجودی '.(int)$g['stock'],'callback_data'=>'buygrp:'.$g['id']]]; } if(!$rows){ $this->showBuyAllPlans($chatId); return; } $this->tg->sendMessage($chatId,'ابتدا دسته سرویس را انتخاب کنید:', ['reply_markup'=>$this->inline($rows)]); }
    private function showBuyPlansInGroup(int $chatId, int $messageId, int $groupId): void { $stmt=$this->db->pdo->prepare("SELECT c.*, COUNT(i.id) AS stock FROM categories c LEFT JOIN inventory i ON i.category_id=c.id AND i.status='available' WHERE c.active=1 AND c.is_test=0 AND c.group_id=? GROUP BY c.id ORDER BY c.sort_order,c.id"); $stmt->execute([$groupId]); $rows=[]; foreach($stmt as $cat){ $rows[]=[['text'=>$cat['title'].' | '.number_format((int)$cat['price']).' تومان | موجودی '.(int)$cat['stock'],'callback_data'=>'buy:'.$cat['id']]]; } $rows[]=[['text'=>'↩️ برگشت به دسته‌ها','callback_data'=>'home']]; if(!$rows){$this->tg->sendMessage($chatId,$this->msg('buy_no_plan'));return;} $this->tg->editMessageText($chatId,$messageId,'پلن موردنظر را انتخاب کنید:', ['reply_markup'=>$this->inline($rows)]); }
    private function showBuyAllPlans(int $chatId): void { $stmt=$this->db->pdo->query("SELECT c.*, COUNT(i.id) AS stock FROM categories c LEFT JOIN inventory i ON i.category_id=c.id AND i.status='available' WHERE c.active=1 AND c.is_test=0 GROUP BY c.id ORDER BY c.sort_order"); $rows=[]; foreach($stmt as $cat){ $rows[]=[['text'=>$cat['title'].' | '.number_format((int)$cat['price']).' تومان | موجودی '.(int)$cat['stock'],'callback_data'=>'buy:'.$cat['id']]]; } if(!$rows){$this->tg->sendMessage($chatId,$this->msg('buy_no_plan'));return;} $this->tg->sendMessage($chatId,$this->msg('buy_choose_plan'), ['reply_markup'=>$this->inline($rows)]); }
    private function showCategoryConfirm(int $chatId, int $messageId, int $catId): void { $cat=$this->getCategory($catId); if(!$cat)return; $stmt=$this->db->pdo->prepare("SELECT COUNT(*) FROM inventory WHERE category_id=? AND status='available'"); $stmt->execute([$catId]); $stock=(int)$stmt->fetchColumn(); $text=$this->msg('purchase_confirm',['plan_title'=>h($cat['title']),'price'=>number_format((int)$cat['price']),'stock'=>$stock]); $rows=[[['text'=>'✅ خرید بدون تخفیف','callback_data'=>'confirm:'.$catId]],[['text'=>'🎟 اعمال کد تخفیف','callback_data'=>'discount:'.$catId]],[['text'=>'↩️ برگشت','callback_data'=>'home']]]; $this->tg->editMessageText($chatId,$messageId,$text,['reply_markup'=>$this->inline($rows)]); }

    private function validateDiscount(?string $code, int $userId, int $amount): array { if(!$code) return ['code'=>null,'percent'=>0,'amount'=>0,'row'=>null]; $stmt=$this->db->pdo->prepare('SELECT * FROM discount_codes WHERE UPPER(code)=UPPER(?)'); $stmt->execute([trim($code)]); $d=$stmt->fetch(); if(!$d) throw new RuntimeException('کد تخفیف معتبر نیست.'); if((int)$d['active']!==1) throw new RuntimeException('کد تخفیف غیرفعال است.'); if(!empty($d['expires_at']) && strtotime($d['expires_at']) < time()) throw new RuntimeException('کد تخفیف منقضی شده است.'); if((int)$d['min_amount']>0 && $amount < (int)$d['min_amount']) throw new RuntimeException('مبلغ خرید برای این کد تخفیف کافی نیست.'); if((int)$d['usage_limit']>0 && (int)$d['used_count'] >= (int)$d['usage_limit']) throw new RuntimeException('ظرفیت استفاده از این کد تمام شده است.'); $stmt=$this->db->pdo->prepare('SELECT COUNT(*) FROM discount_redemptions WHERE discount_id=? AND user_id=?'); $stmt->execute([$d['id'],$userId]); if((int)$stmt->fetchColumn()>0) throw new RuntimeException('شما قبلا از این کد تخفیف استفاده کرده‌اید.'); $discount=(int)floor($amount * (int)$d['percent'] / 100); if((int)$d['max_discount']>0) $discount=min($discount,(int)$d['max_discount']); return ['code'=>$d['code'],'percent'=>(int)$d['percent'],'amount'=>max(0,$discount),'row'=>$d]; }

    private function purchaseCategory(int $chatId, array $user, int $catId, ?string $discountCode = null): void { try { $this->db->pdo->exec('BEGIN IMMEDIATE'); $cat=$this->getCategory($catId); if(!$cat || !(int)$cat['active']) throw new RuntimeException('این پلن فعال نیست.'); $stmt=$this->db->pdo->prepare('SELECT * FROM users WHERE id=?'); $stmt->execute([$user['id']]); $fresh=$stmt->fetch(); if(!$fresh) throw new RuntimeException('کاربر پیدا نشد.'); $price=(int)$cat['price']; $discount=$this->validateDiscount($discountCode, (int)$fresh['id'], $price); $final=max(0,$price-(int)$discount['amount']); if((int)$fresh['balance'] < $final) throw new RuntimeException($this->msg('insufficient_balance', ['balance'=>number_format((int)$fresh['balance']),'price'=>number_format($price),'final_price'=>number_format($final)])); $stmt=$this->db->pdo->prepare("SELECT * FROM inventory WHERE category_id=? AND status='available' ORDER BY id LIMIT 1"); $stmt->execute([$catId]); $item=$stmt->fetch(); if(!$item) throw new RuntimeException($this->msg('out_of_stock', ['plan_title'=>$cat['title'] ?? ''])); $now=now_utc(); $newBalance=(int)$fresh['balance']-$final; $stmt=$this->db->pdo->prepare('UPDATE users SET balance=?, updated_at=? WHERE id=?'); $stmt->execute([$newBalance,$now,$fresh['id']]); $stmt=$this->db->pdo->prepare("UPDATE inventory SET status='sold', sold_to=?, sold_at=? WHERE id=? AND status='available'"); $stmt->execute([$fresh['id'],$now,$item['id']]); if($stmt->rowCount()!==1) throw new RuntimeException('موجودی همزمان خریداری شد؛ دوباره تلاش کنید.'); $stmt=$this->db->pdo->prepare('INSERT INTO orders(user_id,category_id,inventory_id,amount,discount_code,discount_percent,discount_amount,final_amount,status,created_at,delivered_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)'); $stmt->execute([$fresh['id'],$catId,$item['id'],$price,$discount['code'],$discount['percent'],$discount['amount'],$final,'delivered',$now,$now]); $orderId=(int)$this->db->pdo->lastInsertId(); if($discount['row']){ $stmt=$this->db->pdo->prepare('UPDATE discount_codes SET used_count=used_count+1, updated_at=? WHERE id=?'); $stmt->execute([$now,$discount['row']['id']]); $stmt=$this->db->pdo->prepare('INSERT INTO discount_redemptions(discount_id,user_id,order_id,amount,created_at) VALUES(?,?,?,?,?)'); $stmt->execute([$discount['row']['id'],$fresh['id'],$orderId,$discount['amount'],$now]); } $refReward=0; if($this->db->setting('referral_enabled','1')==='1'){ $refReward=$this->db->rewardReferralOnOrder((int)$fresh['id'],$orderId,$final,(int)$this->db->setting('referral_reward_percent','10')); } $config=$this->crypto->decrypt($item['encrypted_config']); $sub=''; if(!empty($item['encrypted_sub_link'])) $sub=$this->crypto->decrypt($item['encrypted_sub_link']); $this->db->logSecurity('user',$fresh['telegram_id'],'order_delivered','order',$orderId,['category'=>$cat['title'],'final'=>$final,'discount'=>$discount['amount']]); $this->db->pdo->commit(); $subBlock=$sub!=='' ? "لینک ساب:\n<code>".h($sub)."</code>" : ''; $msg=$this->msg('purchase_success',['plan_title'=>h($cat['title']),'final_price'=>number_format($final),'balance'=>number_format($newBalance),'config'=>'<code>'.h($config).'</code>','sub_link'=>h($sub),'sub_block'=>$subBlock,'order_id'=>$orderId]); $this->tg->sendMessage($chatId,$msg); if(($item['qr_mode'] ?? '')==='manual' && !empty($item['qr_file_id'])) { $this->tg->sendPhoto($chatId, $item['qr_file_id'], 'QR Code سرویس شما'); } elseif(($item['qr_mode'] ?? '')==='auto') { $this->tg->sendMessage($chatId, 'QR این کانفیگ به‌صورت اتومات از روی کد در پنل مدیریت قابل ساخت و دانلود است.'); } } catch(Throwable $e){ if($this->db->pdo->inTransaction()) $this->db->pdo->rollBack(); $this->tg->sendMessage($chatId,'❌ '.h($e->getMessage())); } }

    private function deliverTest(int $chatId, array $user): void { if((int)$user['test_used']===1){$this->tg->sendMessage($chatId,'شما قبلا اکانت تست دریافت کرده‌اید.');return;} $stmt=$this->db->pdo->prepare("SELECT * FROM categories WHERE is_test=1 AND active=1 ORDER BY id LIMIT 1"); $stmt->execute(); $cat=$stmt->fetch(); if(!$cat){$this->tg->sendMessage($chatId,'پلن تست فعال نیست.');return;} $this->purchaseCategory($chatId,$user,(int)$cat['id']); $stmt=$this->db->pdo->prepare('UPDATE users SET test_used=1 WHERE id=?'); $stmt->execute([$user['id']]); }
    private function askCharge(int $chatId, int $userId): void { $this->setStep($userId,'charge'); $this->tg->sendMessage($chatId,'مبلغ شارژ کیف پول را به تومان وارد کنید:', ['reply_markup'=>$this->backKeyboard()]); }
    private function sendPaymentLink(int $chatId, int $telegramId, int $amount): void { $zarinOn=$this->db->setting('gateway_zarinpal_enabled','1')==='1'; $zibalOn=$this->db->setting('gateway_zibal_enabled','0')==='1'; $cardOn=$this->db->setting('gateway_card_enabled','1')==='1'; $text="مبلغ شارژ: ".number_format($amount)." تومان\n"; $base=rtrim((string)$this->config['base_url'],'/'); $payload=$telegramId.':'.$amount; $sig=$this->crypto->sign($payload); if($zarinOn){ $url=$base.'/pay/index.php?gw=zarinpal&u='.urlencode((string)$telegramId).'&a='.urlencode((string)$amount).'&s='.urlencode($sig); $text.="\n🔹 پرداخت آنلاین زرین‌پال:\n$url\n"; } if($zibalOn){ $url=$base.'/pay/index.php?gw=zibal&u='.urlencode((string)$telegramId).'&a='.urlencode((string)$amount).'&s='.urlencode($sig); $text.="\n🔹 پرداخت آنلاین زیبال:\n$url\n"; } if($cardOn){ $text.="\n🔹 کارت به کارت:\n".h($this->db->setting('card_info')); } if(!$zarinOn && !$zibalOn && !$cardOn) $text='در حال حاضر هیچ درگاهی فعال نیست.'; $this->tg->sendMessage($chatId,$text); }
    private function redeemGift(int $chatId, array $user, string $code): void { try { $this->db->pdo->exec('BEGIN IMMEDIATE'); $stmt=$this->db->pdo->prepare('SELECT * FROM gift_codes WHERE code=?'); $stmt->execute([trim($code)]); $gift=$stmt->fetch(); if(!$gift) throw new RuntimeException('کد هدیه معتبر نیست.'); if(!empty($gift['used_by'])) throw new RuntimeException('این کد قبلا استفاده شده است.'); $now=now_utc(); $stmt=$this->db->pdo->prepare('UPDATE gift_codes SET used_by=?, used_at=? WHERE id=? AND used_by IS NULL'); $stmt->execute([$user['id'],$now,$gift['id']]); $stmt=$this->db->pdo->prepare('UPDATE users SET balance=balance+?, updated_at=? WHERE id=?'); $stmt->execute([(int)$gift['amount'],$now,$user['id']]); $this->setStep($user['id'],'none'); $this->db->pdo->commit(); $this->tg->sendMessage($chatId,'✅ کد هدیه اعمال شد. مبلغ: '.number_format((int)$gift['amount']).' تومان',['reply_markup'=>$this->mainKeyboard($this->isAdmin((int)$user['telegram_id']))]); } catch(Throwable $e){ if($this->db->pdo->inTransaction()) $this->db->pdo->rollBack(); $this->tg->sendMessage($chatId,'❌ '.h($e->getMessage())); } }
    private function showAccount(int $chatId, array $user): void { $stmt=$this->db->pdo->prepare('SELECT COUNT(*) FROM orders WHERE user_id=?'); $stmt->execute([$user['id']]); $orders=(int)$stmt->fetchColumn(); $verified=(int)$user['is_verified']===1?'تایید شده':'تایید نشده'; $this->tg->sendMessage($chatId,$this->msg('account_message',['telegram_id'=>$user['telegram_id'],'username'=>$user['username'] ?: '-','phone'=>$user['phone'] ?: '-','verified'=>$verified,'balance'=>number_format((int)$user['balance']),'orders'=>$orders])); }
    private function showReferral(int $chatId, array $user): void {
        $code = (string)($user['ref_code'] ?? BotDatabase::makeRefCode((int)$user['telegram_id']));
        $botUsername = trim((string)($this->config['bot_username'] ?? ''));
        $link = $botUsername !== '' ? 'https://t.me/' . $botUsername . '?start=ref_' . $code : 'کد رفرال: ' . $code;
        $stats = $this->db->referralStats((int)$user['id']);
        $percent = (int)$this->db->setting('referral_reward_percent', '10');
        $enabled = $this->db->setting('referral_enabled', '1') === '1' ? 'فعال' : 'غیرفعال';
        $this->tg->sendMessage($chatId, $this->msg('referral_message', ['status'=>$enabled,'percent'=>$percent,'invited'=>(int)$stats['invited'],'earned'=>number_format((int)$stats['earned']),'referral_link'=>$link]));
    }

    private function showUserOrders(int $chatId, int $userId): void { $stmt=$this->db->pdo->prepare('SELECT o.id,o.created_at,c.title,i.encrypted_config,i.encrypted_sub_link FROM orders o JOIN categories c ON c.id=o.category_id JOIN inventory i ON i.id=o.inventory_id WHERE o.user_id=? ORDER BY o.id DESC LIMIT 10'); $stmt->execute([$userId]); $rows=$stmt->fetchAll(); if(!$rows){$this->tg->sendMessage($chatId,'شما هنوز سرویسی خریداری نکرده‌اید.');return;} foreach($rows as $r){ $config=$this->crypto->decrypt($r['encrypted_config']); $sub=!empty($r['encrypted_sub_link'])?$this->crypto->decrypt($r['encrypted_sub_link']):''; $text="#".(int)$r['id'].' - '.h($r['title']).' - '.h($r['created_at'])."\n<code>".h($config)."</code>"; if($sub!=='') $text.="\nSUB: <code>".h($sub)."</code>"; $this->tg->sendMessage($chatId,$text); } }

    private function showTickets(int $chatId, int $userId): void { $stmt=$this->db->pdo->prepare('SELECT * FROM tickets WHERE user_id=? ORDER BY last_message_at DESC LIMIT 10'); $stmt->execute([$userId]); $rows=[[['text'=>'➕ تیکت جدید','callback_data'=>'ticket_new']]]; foreach($stmt as $t){ $rows[]=[['text'=>'#'.$t['id'].' | '.$t['subject'].' | '.$t['status'],'callback_data'=>'ticket_open:'.$t['id']]]; } $this->tg->sendMessage($chatId,'تیکت‌های شما:', ['reply_markup'=>$this->inline($rows)]); }
    private function createTicket(int $userId, string $subject, string $firstMessage=''): int { $now=now_utc(); $stmt=$this->db->pdo->prepare('INSERT INTO tickets(user_id,subject,status,created_at,updated_at,last_message_at) VALUES(?,?,?,?,?,?)'); $stmt->execute([$userId,$subject,'open',$now,$now,$now]); $id=(int)$this->db->pdo->lastInsertId(); if($firstMessage!=='') $this->addTicketMessage($id,$userId,'system',$firstMessage,false); $this->db->logSecurity('user',$userId,'ticket_create','ticket',$id,['subject'=>$subject]); return $id; }
    private function addTicketMessage(int $ticketId, int $userId, string $sender, string $message, bool $notify=true): void { $now=now_utc(); $stmt=$this->db->pdo->prepare('INSERT INTO ticket_messages(ticket_id,sender_type,sender_user_id,message,created_at) VALUES(?,?,?,?,?)'); $stmt->execute([$ticketId,$sender,$userId,$message,$now]); $stmt=$this->db->pdo->prepare('UPDATE tickets SET status=CASE WHEN ?="user" THEN "open" ELSE status END, updated_at=?, last_message_at=? WHERE id=?'); $stmt->execute([$sender,$now,$now,$ticketId]); if($notify && $sender==='user' && !empty($this->config['admin_id'])) $this->tg->sendMessage((int)$this->config['admin_id'],"🎫 پیام جدید در تیکت #$ticketId\n".h($message)); }
    private function openTicketFromBot(int $chatId, int $userId, int $ticketId): void { $stmt=$this->db->pdo->prepare('SELECT * FROM tickets WHERE id=? AND user_id=?'); $stmt->execute([$ticketId,$userId]); $t=$stmt->fetch(); if(!$t){$this->tg->sendMessage($chatId,'تیکت پیدا نشد.');return;} $stmt=$this->db->pdo->prepare('SELECT * FROM ticket_messages WHERE ticket_id=? ORDER BY id DESC LIMIT 6'); $stmt->execute([$ticketId]); $messages=array_reverse($stmt->fetchAll()); $text='🎫 تیکت #'.$ticketId.' - '.h($t['subject'])."\n"; foreach($messages as $m) $text.="\n".($m['sender_type']==='admin'?'ادمین':'شما').': '.h($m['message']); $rows=[[['text'=>'✍️ ارسال پیام','callback_data'=>'ticket_reply_set:'.$ticketId]],[['text'=>'بستن تیکت','callback_data'=>'ticket_close:'.$ticketId]]]; $this->setStep($userId,'ticket_reply:'.$ticketId); $this->tg->sendMessage($chatId,$text."\n\nبرای پاسخ، پیام خود را همین‌جا بفرستید.", ['reply_markup'=>$this->backKeyboard()]); }
    private function closeTicketFromBot(int $chatId, int $userId, int $ticketId): void { $stmt=$this->db->pdo->prepare("UPDATE tickets SET status='closed', updated_at=? WHERE id=? AND user_id=?"); $stmt->execute([now_utc(),$ticketId,$userId]); $this->setStep($userId,'none'); $this->tg->sendMessage($chatId,'تیکت بسته شد.', ['reply_markup'=>$this->mainKeyboard(false)]); }

    private function adminChooseCategory(int $chatId, string $mode): void {
        if ($mode === 'add') {
            $stmt=$this->db->pdo->query('SELECT * FROM plan_groups WHERE active=1 ORDER BY sort_order,id');
            $rows=[];
            foreach($stmt as $g){ $rows[]=[['text'=>'📁 '.$g['title'],'callback_data'=>'admin_add_group:'.$g['id']]]; }
            if(!$rows){ $this->tg->sendMessage($chatId,'هیچ دسته‌ای ثبت نشده است. ابتدا از پنل وب یا دیتابیس دسته بسازید.'); return; }
            $this->tg->sendMessage($chatId,'مرحله ۱ از ۵: دسته کانفیگ را انتخاب کنید:', ['reply_markup'=>$this->inline($rows)]);
            return;
        }
        $stmt=$this->db->pdo->query("SELECT c.*,g.title AS group_title FROM categories c LEFT JOIN plan_groups g ON g.id=c.group_id ORDER BY g.sort_order,c.sort_order,c.id");
        $rows=[];
        foreach($stmt as $cat){$rows[]=[['text'=>($cat['group_title']? $cat['group_title'].' / ':'').$cat['title'].' | '.number_format((int)$cat['price']),'callback_data'=>'admin_price:'.$cat['id']]];}
        $this->tg->sendMessage($chatId,'پلن را انتخاب کنید:', ['reply_markup'=>$this->inline($rows)]);
    }
    private function showAdminPlanButtons(int $chatId, int $groupId): void {
        $stmt=$this->db->pdo->prepare('SELECT * FROM categories WHERE group_id=? ORDER BY sort_order,id');
        $stmt->execute([$groupId]);
        $rows=[];
        foreach($stmt as $cat){ $rows[]=[['text'=>'📦 '.$cat['title'].' | '.number_format((int)$cat['price']).' تومان','callback_data'=>'admin_add_plan:'.$cat['id']]]; }
        if(!$rows){ $this->tg->sendMessage($chatId,'در این دسته پلنی وجود ندارد. از پنل وب پلن اضافه کنید.'); return; }
        $this->tg->sendMessage($chatId,'مرحله ۲ از ۵: پلن مربوط به کانفیگ را انتخاب کنید:', ['reply_markup'=>$this->inline($rows)]);
    }
    private function parseConfigAndSub(string $text): array { $lines=preg_split('/\R/',trim($text)); $sub=''; $config=[]; foreach($lines as $line){ if(preg_match('/^SUB\s*:\s*(.+)$/iu',$line,$m)) $sub=trim($m[1]); else $config[]=$line; } return [trim(implode("\n",$config)),$sub]; }
    private function setTempAddInventory(int $userId, array $state): void { $this->db->setSetting('tmp_add_inventory_'.$userId, json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); }
    private function getTempAddInventory(int $userId): array { $raw=$this->db->setting('tmp_add_inventory_'.$userId, '{}'); $data=json_decode($raw,true); return is_array($data)?$data:[]; }
    private function finishAdminInventoryFromState(int $chatId, int $adminUserId, string $qrMode='auto', ?string $qrFileId=null): void {
        $state=$this->getTempAddInventory($adminUserId);
        $catId=(int)($state['category_id'] ?? 0);
        $config=trim((string)($state['config'] ?? ''));
        $sub=trim((string)($state['sub'] ?? ''));
        if($catId<=0 || $config===''){ $this->tg->sendMessage($chatId,'اطلاعات افزودن کانفیگ ناقص است. دوباره از ابتدا شروع کنید.'); $this->setStep($adminUserId,'none'); return; }
        if(!in_array($qrMode,['auto','manual','off'],true)) $qrMode='auto';
        $stmt=$this->db->pdo->prepare('INSERT INTO inventory(category_id, encrypted_config, encrypted_sub_link, note, qr_mode, qr_file_id, status, added_by, created_at) VALUES(?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$catId,$this->crypto->encrypt($config),$sub!==''?$this->crypto->encrypt($sub):null,'افزوده شده از تلگرام',$qrMode,$qrFileId,'available',$adminUserId,now_utc()]);
        $id=(int)$this->db->pdo->lastInsertId();
        $this->db->logSecurity('telegram_admin',$adminUserId,'inventory_add_step_by_step','inventory',$id,['category_id'=>$catId,'has_sub'=>$sub!=='','qr_mode'=>$qrMode]);
        $this->db->setSetting('tmp_add_inventory_'.$adminUserId, '{}');
        $this->setStep($adminUserId,'none');
        $this->tg->sendMessage($chatId,"✅ کانفیگ با موفقیت اضافه شد.\nشناسه: #$id\nQR: $qrMode", ['reply_markup'=>$this->adminKeyboard()]);
    }
    private function addInventoryFromText(int $chatId, int $adminUserId, int $catId, string $configText): void { [$config,$sub]=$this->parseConfigAndSub($configText); if($config===''){ $this->tg->sendMessage($chatId,'کانفیگ خالی است.'); return; } $stmt=$this->db->pdo->prepare('INSERT INTO inventory(category_id, encrypted_config, encrypted_sub_link, qr_mode, status, added_by, created_at) VALUES(?,?,?,?,?,?,?)'); $stmt->execute([$catId,$this->crypto->encrypt($config),$sub!==''?$this->crypto->encrypt($sub):null,'auto','available',$adminUserId,now_utc()]); $this->db->logSecurity('telegram_admin',$adminUserId,'inventory_add','inventory',$this->db->pdo->lastInsertId(),['category_id'=>$catId,'has_sub'=>$sub!=='']); $this->setStep($adminUserId,'none'); $this->tg->sendMessage($chatId,'✅ کانفیگ به دیتابیس رمزنگاری‌شده اضافه شد.', ['reply_markup'=>$this->adminKeyboard()]); }
    private function adminStats(int $chatId): void { $users=(int)$this->db->pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(); $orders=(int)$this->db->pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn(); $available=(int)$this->db->pdo->query("SELECT COUNT(*) FROM inventory WHERE status='available'")->fetchColumn(); $income=(int)$this->db->pdo->query('SELECT COALESCE(SUM(final_amount),SUM(amount),0) FROM orders')->fetchColumn(); $paid=(int)$this->db->pdo->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='paid'")->fetchColumn(); $tickets=(int)$this->db->pdo->query("SELECT COUNT(*) FROM tickets WHERE status='open'")->fetchColumn(); $this->tg->sendMessage($chatId,"📊 آمار ربات\nکاربران: $users\nسفارش‌ها: $orders\nموجودی کانفیگ: $available\nتیکت باز: $tickets\nفروش از کیف پول: ".number_format($income)." تومان\nپرداخت‌های موفق: ".number_format($paid).' تومان', ['reply_markup'=>$this->adminKeyboard()]); }
    private function adminStock(int $chatId): void { $stmt=$this->db->pdo->query("SELECT c.title,c.price,COUNT(i.id) AS stock FROM categories c LEFT JOIN inventory i ON i.category_id=c.id AND i.status='available' GROUP BY c.id ORDER BY c.sort_order"); $text="📦 موجودی پلن‌ها:\n"; foreach($stmt as $row){$text.=h($row['title']).' | موجودی: '.(int)$row['stock'].' | قیمت: '.number_format((int)$row['price'])."\n";} $this->tg->sendMessage($chatId,$text, ['reply_markup'=>$this->adminKeyboard()]); }
    private function broadcast(int $chatId, string $text): void { $stmt=$this->db->pdo->query('SELECT telegram_id FROM users WHERE is_blocked=0'); $ok=0;$fail=0; foreach($stmt as $row){$res=$this->tg->sendMessage((int)$row['telegram_id'],$text); if(!empty($res['ok']))$ok++;else$fail++; usleep(60000);} $this->tg->sendMessage($chatId,"پیام همگانی ارسال شد. موفق: $ok | ناموفق: $fail", ['reply_markup'=>$this->adminKeyboard()]); }
}
