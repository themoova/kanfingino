<?php
class BotCrypto {
    private string $key;

    public function __construct(string $appKey) {
        if ($appKey === '') {
            throw new RuntimeException('APP_KEY is empty. Run installer again.');
        }
        $decoded = base64_decode($appKey, true);
        $this->key = $decoded !== false && strlen($decoded) >= 32 ? substr($decoded, 0, 32) : hash('sha256', $appKey, true);
    }

    public static function newKey(): string {
        return base64_encode(random_bytes(32));
    }

    public function encrypt(string $plain): string {
        $iv = random_bytes(12);
        $tag = '';
        $cipher = openssl_encrypt($plain, 'aes-256-gcm', $this->key, OPENSSL_RAW_DATA, $iv, $tag);
        if ($cipher === false) {
            throw new RuntimeException('Encryption failed.');
        }
        return base64_encode(json_encode([
            'v' => 1,
            'iv' => base64_encode($iv),
            'tag' => base64_encode($tag),
            'data' => base64_encode($cipher),
        ], JSON_UNESCAPED_SLASHES));
    }

    public function decrypt(string $payload): string {
        $json = base64_decode($payload, true);
        $box = $json ? json_decode($json, true) : null;
        if (!is_array($box) || empty($box['iv']) || empty($box['tag']) || empty($box['data'])) {
            throw new RuntimeException('Encrypted payload is invalid.');
        }
        $plain = openssl_decrypt(
            base64_decode($box['data'], true),
            'aes-256-gcm',
            $this->key,
            OPENSSL_RAW_DATA,
            base64_decode($box['iv'], true),
            base64_decode($box['tag'], true)
        );
        if ($plain === false) {
            throw new RuntimeException('Decryption failed. Wrong APP_KEY?');
        }
        return $plain;
    }

    public function sign(string $data): string {
        return hash_hmac('sha256', $data, $this->key);
    }

    public function verify(string $data, string $signature): bool {
        return hash_equals($this->sign($data), $signature);
    }
}
