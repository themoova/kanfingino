<?php
require_once __DIR__ . '/Helpers.php';

class BotDatabase {
    public PDO $pdo;

    public function __construct(string $dbPath) {
        $dir = dirname($dbPath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $this->pdo = new PDO('sqlite:' . $dbPath, null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $this->pdo->exec('PRAGMA journal_mode=WAL');
        $this->pdo->exec('PRAGMA foreign_keys=ON');
        $this->pdo->exec('PRAGMA busy_timeout=5000');
    }

    private function tableColumns(string $table): array {
        $stmt = $this->pdo->query('PRAGMA table_info(' . $table . ')');
        $cols = [];
        foreach ($stmt->fetchAll() as $row) {
            $cols[] = $row['name'];
        }
        return $cols;
    }

    private function addColumnIfMissing(string $table, string $column, string $definition): void {
        if (!in_array($column, $this->tableColumns($table), true)) {
            $this->pdo->exec('ALTER TABLE ' . $table . ' ADD COLUMN ' . $column . ' ' . $definition);
        }
    }

    public function migrate(): void {
        $sql = [
            "CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_id INTEGER NOT NULL UNIQUE,
                username TEXT,
                first_name TEXT,
                phone TEXT,
                step TEXT NOT NULL DEFAULT 'none',
                balance INTEGER NOT NULL DEFAULT 0,
                test_used INTEGER NOT NULL DEFAULT 0,
                is_verified INTEGER NOT NULL DEFAULT 0,
                is_blocked INTEGER NOT NULL DEFAULT 0,
                note TEXT,
                ref_code TEXT UNIQUE,
                referred_by INTEGER,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )",
            "CREATE TABLE IF NOT EXISTS plan_groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                code TEXT UNIQUE,
                description TEXT,
                active INTEGER NOT NULL DEFAULT 1,
                sort_order INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )",
            "CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER,
                code TEXT NOT NULL UNIQUE,
                title TEXT NOT NULL,
                price INTEGER NOT NULL DEFAULT 0,
                active INTEGER NOT NULL DEFAULT 1,
                is_test INTEGER NOT NULL DEFAULT 0,
                sort_order INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(group_id) REFERENCES plan_groups(id) ON DELETE SET NULL
            )",
            "CREATE TABLE IF NOT EXISTS inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_id INTEGER NOT NULL,
                encrypted_config TEXT NOT NULL,
                encrypted_sub_link TEXT,
                note TEXT,
                qr_mode TEXT NOT NULL DEFAULT 'auto',
                qr_file_id TEXT,
                status TEXT NOT NULL DEFAULT 'available',
                added_by INTEGER,
                sold_to INTEGER,
                created_at TEXT NOT NULL,
                sold_at TEXT,
                FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE CASCADE,
                FOREIGN KEY(sold_to) REFERENCES users(id) ON DELETE SET NULL
            )",
            "CREATE INDEX IF NOT EXISTS idx_inventory_category_status ON inventory(category_id, status)",
            "CREATE INDEX IF NOT EXISTS idx_inventory_sold_to ON inventory(sold_to)",
            "CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                category_id INTEGER NOT NULL,
                inventory_id INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                discount_code TEXT,
                discount_percent INTEGER NOT NULL DEFAULT 0,
                discount_amount INTEGER NOT NULL DEFAULT 0,
                final_amount INTEGER,
                status TEXT NOT NULL DEFAULT 'delivered',
                created_at TEXT NOT NULL,
                delivered_at TEXT,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY(category_id) REFERENCES categories(id),
                FOREIGN KEY(inventory_id) REFERENCES inventory(id)
            )",
            "CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                gateway TEXT NOT NULL DEFAULT 'zarinpal',
                authority TEXT UNIQUE,
                ref_id TEXT,
                status TEXT NOT NULL DEFAULT 'created',
                created_at TEXT NOT NULL,
                verified_at TEXT,
                raw_response TEXT,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            )",
            "CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )",
            "CREATE TABLE IF NOT EXISTS custom_buttons (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                label TEXT NOT NULL,
                action_type TEXT NOT NULL DEFAULT 'text',
                action_value TEXT,
                row_no INTEGER NOT NULL DEFAULT 1,
                sort_order INTEGER NOT NULL DEFAULT 1,
                scope TEXT NOT NULL DEFAULT 'user',
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )",
            "CREATE TABLE IF NOT EXISTS message_templates (
                key TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                group_name TEXT NOT NULL DEFAULT 'general',
                body TEXT NOT NULL,
                variables TEXT,
                sort_order INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL
            )",
            "CREATE TABLE IF NOT EXISTS forced_channels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                title TEXT,
                invite_link TEXT,
                active INTEGER NOT NULL DEFAULT 1,
                sort_order INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )",
            "CREATE TABLE IF NOT EXISTS gift_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT NOT NULL UNIQUE,
                amount INTEGER NOT NULL,
                used_by INTEGER,
                used_at TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(used_by) REFERENCES users(id) ON DELETE SET NULL
            )",
            "CREATE TABLE IF NOT EXISTS discount_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT NOT NULL UNIQUE,
                percent INTEGER NOT NULL,
                max_discount INTEGER NOT NULL DEFAULT 0,
                min_amount INTEGER NOT NULL DEFAULT 0,
                usage_limit INTEGER NOT NULL DEFAULT 0,
                used_count INTEGER NOT NULL DEFAULT 0,
                active INTEGER NOT NULL DEFAULT 1,
                expires_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )",
            "CREATE TABLE IF NOT EXISTS discount_redemptions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                discount_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                order_id INTEGER,
                amount INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(discount_id) REFERENCES discount_codes(id) ON DELETE CASCADE,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE SET NULL
            )",
            "CREATE TABLE IF NOT EXISTS security_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                actor_type TEXT NOT NULL,
                actor_id TEXT,
                action TEXT NOT NULL,
                entity_type TEXT,
                entity_id TEXT,
                ip TEXT,
                user_agent TEXT,
                details TEXT,
                created_at TEXT NOT NULL
            )",
            "CREATE INDEX IF NOT EXISTS idx_security_logs_created ON security_logs(created_at)",
            "CREATE TABLE IF NOT EXISTS anti_spam (
                telegram_id INTEGER PRIMARY KEY,
                window_started_at INTEGER NOT NULL,
                request_count INTEGER NOT NULL,
                blocked_until INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL
            )",
            "CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                subject TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'open',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                last_message_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            )",
            "CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status, last_message_at)",
            "CREATE TABLE IF NOT EXISTS ticket_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER NOT NULL,
                sender_type TEXT NOT NULL,
                sender_user_id INTEGER,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
                FOREIGN KEY(sender_user_id) REFERENCES users(id) ON DELETE SET NULL
            )",
            "CREATE TABLE IF NOT EXISTS user_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                type TEXT NOT NULL,
                reason TEXT,
                actor_id TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            )",
            "CREATE TABLE IF NOT EXISTS referrals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                referrer_user_id INTEGER NOT NULL,
                referred_user_id INTEGER NOT NULL,
                reward_amount INTEGER NOT NULL DEFAULT 0,
                reward_type TEXT NOT NULL DEFAULT 'purchase',
                status TEXT NOT NULL DEFAULT 'pending',
                order_id INTEGER,
                created_at TEXT NOT NULL,
                rewarded_at TEXT,
                FOREIGN KEY(referrer_user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY(referred_user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE SET NULL
            )",
            "CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_user_id, created_at)",
            "CREATE INDEX IF NOT EXISTS idx_referrals_status ON referrals(status, created_at)"
        ];
        foreach ($sql as $q) {
            $this->pdo->exec($q);
        }

        $this->pdo->exec("INSERT OR IGNORE INTO plan_groups(id,title,code,description,active,sort_order,created_at,updated_at) VALUES(1,'عمومی','general','دسته پیش‌فرض پلن‌ها',1,0,'" . now_utc() . "','" . now_utc() . "')");
        $this->addColumnIfMissing('categories', 'group_id', 'INTEGER');
        $this->pdo->exec('UPDATE categories SET group_id=1 WHERE group_id IS NULL OR group_id=0');
        $this->addColumnIfMissing('inventory', 'qr_mode', "TEXT NOT NULL DEFAULT 'auto'");
        $this->addColumnIfMissing('inventory', 'qr_file_id', 'TEXT');
        $this->addColumnIfMissing('users', 'phone', 'TEXT');
        $this->addColumnIfMissing('users', 'is_verified', 'INTEGER NOT NULL DEFAULT 0');
        $this->addColumnIfMissing('users', 'note', 'TEXT');
        $this->addColumnIfMissing('users', 'ref_code', 'TEXT');
        $this->addColumnIfMissing('users', 'referred_by', 'INTEGER');
        $this->addColumnIfMissing('inventory', 'encrypted_sub_link', 'TEXT');
        $this->addColumnIfMissing('inventory', 'note', 'TEXT');
        $this->addColumnIfMissing('orders', 'discount_code', 'TEXT');
        $this->addColumnIfMissing('orders', 'discount_percent', 'INTEGER NOT NULL DEFAULT 0');
        $this->addColumnIfMissing('orders', 'discount_amount', 'INTEGER NOT NULL DEFAULT 0');
        $this->addColumnIfMissing('orders', 'final_amount', 'INTEGER');
        $this->addColumnIfMissing('payments', 'gateway', "TEXT NOT NULL DEFAULT 'zarinpal'");
        $this->addColumnIfMissing('payments', 'meta', 'TEXT');
        $this->pdo->exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_ref_code ON users(ref_code)');
        $this->pdo->exec('CREATE INDEX IF NOT EXISTS idx_users_referred_by ON users(referred_by)');
        $this->seedMessageTemplates();
        $this->seedForcedChannelFromOldSetting();
    }

    public function seedDefaults(array $prices = []): void {
        $this->pdo->exec("INSERT OR IGNORE INTO plan_groups(id,title,code,description,active,sort_order,created_at,updated_at) VALUES(1,'عمومی','general','دسته پیش‌فرض پلن‌ها',1,0,'" . now_utc() . "','" . now_utc() . "')");
        $stmt = $this->pdo->prepare('INSERT OR IGNORE INTO categories(group_id,code,title,price,active,is_test,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)');
        foreach (self::defaultCategories() as $cat) {
            $price = $prices[$cat['code']] ?? $cat['price'];
            $stmt->execute([1, $cat['code'], $cat['title'], $price, 1, $cat['is_test'], $cat['sort_order'], now_utc(), now_utc()]);
        }
        $settings = [
            'help_text' => 'راهنمای اتصال هنوز تنظیم نشده است.',
            'support_text' => 'برای پشتیبانی از بخش تیکت داخل ربات استفاده کنید.',
            'card_info' => 'شماره کارت هنوز تنظیم نشده است.',
            'force_channel' => 'none',
            'welcome_bonus' => '0',
            'auth_required' => '0',
            'gateway_zarinpal_enabled' => '1',
            'gateway_zibal_enabled' => '0',
            'gateway_card_enabled' => '1',
            'zibal_merchant' => '',
            'rate_window_seconds' => '10',
            'rate_max_requests' => '12',
            'rate_block_seconds' => '60',
            'referral_enabled' => '1',
            'referral_reward_percent' => '10',
            'referral_signup_bonus' => '0',
        ];
        $stmt = $this->pdo->prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)');
        foreach ($settings as $k => $v) {
            $stmt->execute([$k, $v]);
        }
    }

    public static function defaultCategories(): array {
        $rows = [
            ['test', '🎁 اکانت تست', 0, 1],
            ['v2ray', '🚀 سرویس عمومی V2Ray', 0, 0],
        ];
        $countries = [
            ['de', '🇩🇪 آلمان'], ['us', '🇺🇸 آمریکا'], ['at', '🇦🇹 اتریش'],
            ['tr', '🇹🇷 ترکیه'], ['fr', '🇫🇷 فرانسه'], ['nl', '🇳🇱 هلند'],
        ];
        $durations = [
            ['1m', 'یک ماهه'], ['3m', 'سه ماهه'], ['6m', 'شش ماهه'], ['12m', 'یک ساله'],
        ];
        foreach ($countries as $c) {
            foreach ($durations as $d) {
                $rows[] = [$c[0] . '_' . $d[0], $c[1] . ' - ' . $d[1], 0, 0];
            }
        }
        $out = [];
        $i = 1;
        foreach ($rows as $r) {
            $out[] = ['code' => $r[0], 'title' => $r[1], 'price' => $r[2], 'is_test' => $r[3], 'sort_order' => $i++];
        }
        return $out;
    }

    public function setting(string $key, string $default = ''): string {
        $stmt = $this->pdo->prepare('SELECT value FROM settings WHERE key=?');
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        return $row ? (string)$row['value'] : $default;
    }

    public function setSetting(string $key, string $value): void {
        $stmt = $this->pdo->prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
        $stmt->execute([$key, $value]);
    }

    public static function makeRefCode(int $telegramId): string {
        return 'K' . strtoupper(substr(hash('sha256', 'komfingino-ref-' . $telegramId), 0, 8));
    }

    public function upsertUser(int $telegramId, ?string $username, ?string $firstName): array {
        $bonus = (int)$this->setting('welcome_bonus', '0');
        $now = now_utc();
        $refCode = self::makeRefCode($telegramId);
        $stmt = $this->pdo->prepare('INSERT OR IGNORE INTO users(telegram_id,username,first_name,balance,ref_code,created_at,updated_at) VALUES(?,?,?,?,?,?,?)');
        $stmt->execute([$telegramId, $username, $firstName, $bonus, $refCode, $now, $now]);
        $stmt = $this->pdo->prepare('UPDATE users SET username=?, first_name=?, ref_code=COALESCE(NULLIF(ref_code,\'\'), ?), updated_at=? WHERE telegram_id=?');
        $stmt->execute([$username, $firstName, $refCode, $now, $telegramId]);
        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE telegram_id=?');
        $stmt->execute([$telegramId]);
        return $stmt->fetch();
    }

    public function getUserByTelegramId(int $telegramId): ?array {
        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE telegram_id=?');
        $stmt->execute([$telegramId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function getUserById(int $id): ?array {
        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE id=?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function logSecurity(string $actorType, $actorId, string $action, ?string $entityType = null, $entityId = null, array|string|null $details = null): void {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $payload = is_array($details) ? json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : $details;
        $stmt = $this->pdo->prepare('INSERT INTO security_logs(actor_type,actor_id,action,entity_type,entity_id,ip,user_agent,details,created_at) VALUES(?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$actorType, (string)$actorId, $action, $entityType, $entityId === null ? null : (string)$entityId, $ip, $ua, $payload, now_utc()]);
    }

    public function addUserTransaction(int $userId, int $amount, string $type, string $reason = '', $actorId = null): void {
        $stmt = $this->pdo->prepare('INSERT INTO user_transactions(user_id, amount, type, reason, actor_id, created_at) VALUES(?,?,?,?,?,?)');
        $stmt->execute([$userId, $amount, $type, $reason, $actorId === null ? null : (string)$actorId, now_utc()]);
    }


    public function findUserByRefCode(string $code): ?array {
        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE UPPER(ref_code)=UPPER(?) LIMIT 1');
        $stmt->execute([trim($code)]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function assignReferral(int $referredUserId, int $referrerUserId): bool {
        if ($referredUserId <= 0 || $referrerUserId <= 0 || $referredUserId === $referrerUserId) {
            return false;
        }
        $now = now_utc();
        $stmt = $this->pdo->prepare('UPDATE users SET referred_by=?, updated_at=? WHERE id=? AND (referred_by IS NULL OR referred_by=0)');
        $stmt->execute([$referrerUserId, $now, $referredUserId]);
        if ($stmt->rowCount() !== 1) {
            return false;
        }
        $stmt = $this->pdo->prepare('INSERT OR IGNORE INTO referrals(referrer_user_id,referred_user_id,reward_amount,reward_type,status,created_at) VALUES(?,?,?,?,?,?)');
        $stmt->execute([$referrerUserId, $referredUserId, 0, 'signup', 'pending', $now]);
        return true;
    }

    public function rewardReferralOnOrder(int $buyerUserId, int $orderId, int $finalAmount, int $percent): int {
        if ($percent <= 0 || $finalAmount <= 0) {
            return 0;
        }
        $stmt = $this->pdo->prepare('SELECT referred_by FROM users WHERE id=?');
        $stmt->execute([$buyerUserId]);
        $referrer = (int)$stmt->fetchColumn();
        if ($referrer <= 0 || $referrer === $buyerUserId) {
            return 0;
        }
        $reward = (int)floor($finalAmount * $percent / 100);
        if ($reward <= 0) {
            return 0;
        }
        $now = now_utc();
        $stmt = $this->pdo->prepare('INSERT OR IGNORE INTO referrals(referrer_user_id,referred_user_id,reward_amount,reward_type,status,order_id,created_at,rewarded_at) VALUES(?,?,?,?,?,?,?,?)');
        $stmt->execute([$referrer, $buyerUserId, $reward, 'purchase', 'paid', $orderId, $now, $now]);
        $stmt = $this->pdo->prepare('UPDATE users SET balance=balance+?, updated_at=? WHERE id=?');
        $stmt->execute([$reward, $now, $referrer]);
        $this->addUserTransaction($referrer, $reward, 'referral_reward', 'پاداش رفرال سفارش #' . $orderId, 'system');
        $this->logSecurity('system', 'referral', 'referral_reward_paid', 'order', $orderId, ['buyer_user_id'=>$buyerUserId, 'referrer_user_id'=>$referrer, 'amount'=>$reward, 'percent'=>$percent]);
        return $reward;
    }

    public function referralStats(int $userId): array {
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM users WHERE referred_by=?');
        $stmt->execute([$userId]);
        $invited = (int)$stmt->fetchColumn();
        $stmt = $this->pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM user_transactions WHERE user_id=? AND type='referral_reward'");
        $stmt->execute([$userId]);
        $earned = (int)$stmt->fetchColumn();
        return ['invited'=>$invited, 'earned'=>$earned];
    }



    public static function defaultMessageTemplates(): array {
        return [
            ['welcome_message','خوش‌آمدگویی','start','سلام {first_name} عزیز 👋\nبه {bot_name} خوش اومدی.\n\nاز منوی زیر یکی از گزینه‌ها رو انتخاب کن.', '{first_name},{bot_name},{telegram_id},{username},{balance}', 10],
            ['main_menu_invalid','دستور نامعتبر','start','دستور نامعتبر است. از منوی زیر استفاده کنید.', '{bot_name}', 20],
            ['account_message','حساب کاربری','user','👨🏼‍💻 حساب کاربری\nشناسه عددی: {telegram_id}\nیوزرنیم: @{username}\nشماره: {phone}\nاحراز هویت: {verified}\nموجودی: {balance} تومان\nتعداد سرویس‌ها: {orders}', '{telegram_id},{username},{phone},{verified},{balance},{orders}', 30],
            ['auth_request','درخواست احراز هویت','auth','برای استفاده از ربات باید شماره موبایل خودتان را با دکمه زیر ارسال کنید.', '{bot_name}', 40],
            ['auth_success','تایید شماره','auth','احراز هویت شماره با موفقیت انجام شد ✅', '{phone}', 50],
            ['blocked_user','کاربر مسدود','security','حساب شما توسط مدیریت غیرفعال شده است.', '{telegram_id}', 60],
            ['anti_spam_block','ضداسپم','security','درخواست‌های شما زیاد است. کمی بعد دوباره تلاش کنید.', '{telegram_id}', 70],
            ['forced_join','عضویت اجباری','security','برای استفاده از ربات ابتدا در کانال‌های زیر عضو شوید:\n{channels}\n\nبعد دوباره /start را ارسال کنید.', '{channels}', 80],
            ['buy_choose_plan','انتخاب پلن','purchase','پلن موردنظر را انتخاب کنید:', '{bot_name}', 90],
            ['buy_no_plan','بدون پلن','purchase','فعلاً پلنی فعال نیست.', '{bot_name}', 100],
            ['purchase_confirm','تایید خرید','purchase','پلن: {plan_title}\nقیمت: {price} تومان\nموجودی: {stock}', '{plan_title},{price},{stock}', 110],
            ['discount_request','درخواست کد تخفیف','discount','کد تخفیف درصدی را ارسال کنید:', '{plan_title}', 120],
            ['insufficient_balance','موجودی ناکافی','purchase','موجودی کیف پول کافی نیست. لطفاً ابتدا کیف پول را شارژ کنید.', '{balance},{price},{final_price}', 130],
            ['out_of_stock','اتمام موجودی','purchase','موجودی این پلن تمام شده است.', '{plan_title}', 140],
            ['purchase_success','تحویل سرویس','delivery','✅ خرید با موفقیت انجام شد.\nپلن: {plan_title}\nقیمت نهایی: {final_price} تومان\nموجودی جدید: {balance} تومان\n\nکانفیگ شما:\n{config}\n{sub_block}', '{plan_title},{final_price},{balance},{config},{sub_link},{sub_block},{order_id}', 150],
            ['charge_request','درخواست شارژ','payment','مبلغ شارژ کیف پول را به تومان وارد کنید:', '{bot_name}', 160],
            ['payment_links','لینک پرداخت','payment','مبلغ شارژ: {amount} تومان\n{payment_links}\n{card_block}', '{amount},{payment_links},{card_block}', 170],
            ['payment_success','پرداخت موفق','payment','✅ پرداخت شما تایید شد و مبلغ {amount} تومان به کیف پول شما افزوده شد. کد پیگیری: {ref_id}', '{amount},{ref_id},{gateway}', 180],
            ['payment_failed','پرداخت ناموفق','payment','پرداخت ناموفق یا لغو شد.', '{gateway}', 190],
            ['gift_request','درخواست کد هدیه','gift','کد هدیه را ارسال کنید:', '{}', 200],
            ['gift_success','کد هدیه موفق','gift','✅ کد هدیه اعمال شد. مبلغ: {amount} تومان', '{amount}', 210],
            ['gift_invalid','کد هدیه نامعتبر','gift','کد هدیه معتبر نیست یا قبلاً استفاده شده است.', '{code}', 220],
            ['support_message','پشتیبانی','support','برای پشتیبانی از بخش تیکت داخل ربات استفاده کنید.', '{bot_name}', 230],
            ['help_message','آموزش اتصال','support','راهنمای اتصال هنوز تنظیم نشده است.', '{bot_name}', 240],
            ['ticket_list','لیست تیکت‌ها','ticket','تیکت‌های شما:', '{bot_name}', 250],
            ['ticket_subject_request','درخواست موضوع تیکت','ticket','موضوع تیکت را بفرستید:', '{}', 260],
            ['ticket_created','ساخت تیکت','ticket','تیکت #{ticket_id} ساخته شد. پیام خود را بفرستید:', '{ticket_id}', 270],
            ['ticket_message_saved','ثبت پیام تیکت','ticket','پیام شما در تیکت ثبت شد. پاسخ ادمین همین‌جا ارسال می‌شود.', '{ticket_id}', 280],
            ['ticket_admin_reply','پاسخ تیکت','ticket','📩 پاسخ جدید تیکت شما:\n{message}', '{message},{ticket_id}', 290],
            ['referral_message','رفرال','referral','👥 سیستم رفرال {bot_name}\nوضعیت: {status}\nپاداش خرید زیرمجموعه: {percent}٪\nتعداد زیرمجموعه‌ها: {invited}\nدرآمد رفرال: {earned} تومان\n\nلینک دعوت شما:\n{referral_link}', '{bot_name},{status},{percent},{invited},{earned},{referral_link}', 300],
            ['admin_panel_message','پیام پنل ادمین','admin','پنل مدیریت ربات فعال است.\nپنل وب: {panel_url}', '{panel_url}', 310],
        ];
    }

    public function seedMessageTemplates(): void {
        $stmt = $this->pdo->prepare('INSERT OR IGNORE INTO message_templates(key,title,group_name,body,variables,sort_order,updated_at) VALUES(?,?,?,?,?,?,?)');
        foreach (self::defaultMessageTemplates() as $tpl) {
            $stmt->execute([$tpl[0], $tpl[1], $tpl[2], str_replace('\\n', "\n", $tpl[3]), $tpl[4], $tpl[5], now_utc()]);
        }
    }

    public function renderTemplate(string $key, array $vars = [], string $fallback = ''): string {
        $stmt = $this->pdo->prepare('SELECT body FROM message_templates WHERE key=?');
        $stmt->execute([$key]);
        $body = $stmt->fetchColumn();
        if ($body === false || $body === null || $body === '') {
            $body = $fallback !== '' ? $fallback : $key;
        }
        $defaults = [
            'bot_name' => 'کامفینگینو',
            'first_name' => '',
            'username' => '',
            'telegram_id' => '',
            'balance' => '0',
            'phone' => '-',
            'verified' => '-',
            'config' => '',
            'sub_link' => '',
            'sub_block' => '',
            'payment_links' => '',
            'card_block' => '',
        ];
        $vars = array_merge($defaults, $vars);
        foreach ($vars as $k => $v) {
            $body = str_replace('{' . $k . '}', (string)$v, $body);
        }
        return $body;
    }

    public function seedForcedChannelFromOldSetting(): void {
        $old = trim($this->setting('force_channel', 'none'));
        if ($old === '' || strtolower($old) === 'none') return;
        $username = ltrim($old, '@');
        $stmt = $this->pdo->prepare('INSERT OR IGNORE INTO forced_channels(username,title,invite_link,active,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,?,?)');
        $stmt->execute([$username, '@' . $username, 'https://t.me/' . $username, 1, 0, now_utc(), now_utc()]);
    }

    public function forcedChannels(bool $activeOnly = true): array {
        $sql = 'SELECT * FROM forced_channels' . ($activeOnly ? ' WHERE active=1' : '') . ' ORDER BY sort_order,id';
        return $this->pdo->query($sql)->fetchAll();
    }

}
