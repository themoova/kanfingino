<?php
function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function now_utc() {
    return gmdate('Y-m-d H:i:s');
}

function normalize_amount($value) {
    $value = preg_replace('/[^0-9]/', '', (string)$value);
    return max(0, (int)$value);
}

function normalize_phone($value) {
    $phone = preg_replace('/[^0-9+]/', '', (string)$value);
    if (str_starts_with($phone, '00')) {
        $phone = '+' . substr($phone, 2);
    }
    return substr($phone, 0, 32);
}

function client_ip(): string {
    return $_SERVER['REMOTE_ADDR'] ?? 'cli';
}

function rrmdir_safe($dir, $root) {
    $real = realpath($dir);
    $rootReal = realpath($root);
    if (!$real || !$rootReal || strpos($real, $rootReal) !== 0 || $real === $rootReal) {
        return false;
    }
    $items = array_diff(scandir($real), ['.', '..']);
    foreach ($items as $item) {
        $path = $real . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path) && !is_link($path)) {
            rrmdir_safe($path, $rootReal);
        } else {
            @unlink($path);
        }
    }
    return @rmdir($real);
}

function write_config_file(string $path, array $config): void {
    $export = var_export($config, true);
    $php = "<?php\nreturn " . $export . ";\n";
    if (file_put_contents($path, $php, LOCK_EX) === false) {
        throw new RuntimeException('Cannot write config.php');
    }
    @chmod($path, 0600);
}

function csrf_token(): string {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function csrf_check(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    $token = (string)($_POST['csrf'] ?? '');
    if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $token)) {
        http_response_code(419);
        exit('CSRF token mismatch.');
    }
}
