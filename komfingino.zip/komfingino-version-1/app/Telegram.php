<?php
class TelegramClient {
    private string $token;
    private string $base;

    public function __construct(string $token) {
        $this->token = $token;
        $this->base = 'https://api.telegram.org/bot' . $token . '/';
    }

    public function call(string $method, array $params = []): array {
        $ch = curl_init($this->base . $method);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_POSTFIELDS => $params,
        ]);
        $raw = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        if ($raw === false) {
            return ['ok' => false, 'description' => $err ?: 'curl error'];
        }
        $json = json_decode($raw, true);
        return is_array($json) ? $json : ['ok' => false, 'description' => 'invalid json', 'raw' => $raw];
    }

    public function sendMessage(int|string $chatId, string $text, array $extra = []): array {
        return $this->call('sendMessage', array_merge([
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => true,
        ], $extra));
    }

    public function editMessageText(int|string $chatId, int $messageId, string $text, array $extra = []): array {
        return $this->call('editMessageText', array_merge([
            'chat_id' => $chatId,
            'message_id' => $messageId,
            'text' => $text,
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => true,
        ], $extra));
    }

    public function answerCallback(string $callbackId, string $text = '', bool $alert = false): array {
        return $this->call('answerCallbackQuery', [
            'callback_query_id' => $callbackId,
            'text' => $text,
            'show_alert' => $alert,
        ]);
    }

    public function sendPhoto(int|string $chatId, string $photo, string $caption = '', array $extra = []): array {
        return $this->call('sendPhoto', array_merge([
            'chat_id' => $chatId,
            'photo' => $photo,
            'caption' => $caption,
            'parse_mode' => 'HTML',
        ], $extra));
    }

    public function getChatMember(string $chatId, int $userId): array {
        return $this->call('getChatMember', ['chat_id' => $chatId, 'user_id' => $userId]);
    }
}
