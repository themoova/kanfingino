<?php
return [
    'installed' => false,
    'debug' => false,
    'bot_token' => '',
    'bot_username' => '',
    'bot_name' => 'کامفینگینو',
    'admin_id' => 0,
    'base_url' => '',
    'webhook_secret' => '',
    'app_key' => '',
    'db_path' => __DIR__ . '/storage/bot.sqlite',
    'zarinpal_merchant_id' => '',
    'zarinpal_sandbox' => false,
    'currency' => 'IRT',
    'panel_password_hash' => '',
];
