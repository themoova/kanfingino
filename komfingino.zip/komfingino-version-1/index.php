<?php
require __DIR__ . '/app/Bot.php';

try {
    $bot = new SecureV2RayBot(__DIR__);
    $bot->handleWebhook();
} catch (Throwable $e) {
    http_response_code(500);
    if (defined('BOT_DEBUG') && BOT_DEBUG) {
        echo 'Error: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
    } else {
        echo 'OK';
    }
}
