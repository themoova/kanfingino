#!/usr/bin/env bash
set -Eeuo pipefail

APP_NAME="komfingino"
DEFAULT_BRANCH="main"
DEFAULT_WEBROOT="/var/www/komfingino"

red(){ printf "\033[31m%s\033[0m\n" "$*"; }
green(){ printf "\033[32m%s\033[0m\n" "$*"; }
yellow(){ printf "\033[33m%s\033[0m\n" "$*"; }

require_root() {
  if [ "$(id -u)" -ne 0 ]; then
    red "این اسکریپت باید با sudo یا کاربر root اجرا شود."
    echo "مثال: sudo bash install.sh"
    exit 1
  fi
}

detect_os() {
  if [ ! -f /etc/os-release ]; then
    red "سیستم‌عامل پشتیبانی نمی‌شود. Ubuntu/Debian پیشنهاد می‌شود."
    exit 1
  fi
  . /etc/os-release
  case "${ID:-}" in
    ubuntu|debian) ;;
    *)
      red "این installer برای Ubuntu/Debian نوشته شده است. سیستم فعلی: ${ID:-unknown}"
      exit 1
      ;;
  esac
}

ask_inputs() {
  echo "=============================="
  echo " نصب خودکار کامفینگینو"
  echo " توسعه توسط تمموا"
  echo "=============================="
  echo

  read -rp "دامنه یا ساب‌دامنه ربات را وارد کن، مثل bot.example.com: " DOMAIN
  if [ -z "${DOMAIN}" ]; then
    red "دامنه الزامی است."
    exit 1
  fi

  read -rp "آدرس GitHub repo را وارد کن، مثل https://github.com/USERNAME/komfingino.git: " REPO_URL
  if [ -z "${REPO_URL}" ]; then
    red "آدرس repo الزامی است."
    exit 1
  fi

  read -rp "Branch را وارد کن [${DEFAULT_BRANCH}]: " BRANCH
  BRANCH="${BRANCH:-$DEFAULT_BRANCH}"

  read -rp "مسیر نصب را وارد کن [${DEFAULT_WEBROOT}]: " WEBROOT
  WEBROOT="${WEBROOT:-$DEFAULT_WEBROOT}"

  read -rp "Apache نصب و تنظیم شود؟ [Y/n]: " SETUP_APACHE
  SETUP_APACHE="${SETUP_APACHE:-Y}"

  read -rp "SSL رایگان با Certbot نصب شود؟ [Y/n]: " SETUP_SSL
  SETUP_SSL="${SETUP_SSL:-Y}"
}

install_packages() {
  yellow "در حال نصب پیش‌نیازها..."
  apt update
  DEBIAN_FRONTEND=noninteractive apt install -y \
    git unzip curl ca-certificates apache2 \
    php php-cli php-curl php-sqlite3 php-mbstring php-xml php-zip php-gd php-fileinfo \
    certbot python3-certbot-apache
}

deploy_source() {
  yellow "در حال دریافت سورس از GitHub..."
  mkdir -p "$(dirname "$WEBROOT")"

  if [ -d "$WEBROOT/.git" ]; then
    yellow "پروژه از قبل وجود دارد؛ در حال بروزرسانی..."
    git -C "$WEBROOT" fetch --all --prune
    git -C "$WEBROOT" checkout "$BRANCH"
    git -C "$WEBROOT" pull origin "$BRANCH"
  else
    if [ -d "$WEBROOT" ] && [ "$(ls -A "$WEBROOT" 2>/dev/null)" ]; then
      BACKUP="${WEBROOT}_backup_$(date +%Y%m%d_%H%M%S)"
      yellow "پوشه نصب خالی نیست؛ بکاپ ساخته می‌شود: $BACKUP"
      mv "$WEBROOT" "$BACKUP"
    fi
    git clone --branch "$BRANCH" "$REPO_URL" "$WEBROOT"
  fi

  mkdir -p "$WEBROOT/storage" "$WEBROOT/logs"
  chown -R www-data:www-data "$WEBROOT"
  find "$WEBROOT" -type d -exec chmod 755 {} \;
  find "$WEBROOT" -type f -exec chmod 644 {} \;
  chmod -R 775 "$WEBROOT/storage" "$WEBROOT/logs"

  # امنیت فایل‌های حساس در صورت ساخته شدن
  if [ -f "$WEBROOT/config.php" ]; then
    chmod 640 "$WEBROOT/config.php"
  fi
}

setup_apache() {
  if [[ ! "$SETUP_APACHE" =~ ^[Yy]$ ]]; then
    return
  fi

  yellow "در حال تنظیم Apache..."
  a2enmod rewrite headers >/dev/null

  cat > "/etc/apache2/sites-available/${APP_NAME}.conf" <<APACHE
<VirtualHost *:80>
    ServerName ${DOMAIN}
    DocumentRoot ${WEBROOT}

    <Directory ${WEBROOT}>
        AllowOverride All
        Require all granted
        Options -Indexes +FollowSymLinks
    </Directory>

    <FilesMatch "^(config\\.php|.*\\.sqlite|.*\\.db|.*\\.log)$">
        Require all denied
    </FilesMatch>

    ErrorLog \${APACHE_LOG_DIR}/${APP_NAME}_error.log
    CustomLog \${APACHE_LOG_DIR}/${APP_NAME}_access.log combined
</VirtualHost>
APACHE

  a2dissite 000-default.conf >/dev/null 2>&1 || true
  a2ensite "${APP_NAME}.conf" >/dev/null
  apache2ctl configtest
  systemctl reload apache2
}

setup_ssl() {
  if [[ ! "$SETUP_SSL" =~ ^[Yy]$ ]]; then
    return
  fi

  yellow "در حال نصب SSL برای ${DOMAIN}..."
  certbot --apache -d "$DOMAIN" --non-interactive --agree-tos -m "admin@${DOMAIN}" --redirect || {
    yellow "SSL خودکار انجام نشد. بعداً دستی اجرا کن:"
    echo "certbot --apache -d ${DOMAIN}"
  }
}

final_message() {
  green "نصب سورس روی سرور انجام شد."
  echo
  echo "حالا این آدرس را در مرورگر باز کن و نصب ربات را کامل کن:"
  echo "https://${DOMAIN}/install/"
  echo
  echo "در اینستالر اطلاعات زیر را وارد کن:"
  echo "- Bot Token"
  echo "- Admin Numeric ID"
  echo "- Base URL: https://${DOMAIN}"
  echo "- رمز پنل مدیریت"
  echo "- اطلاعات درگاه‌ها و کارت‌به‌کارت"
  echo
  yellow "بعد از نصب موفق، پوشه install باید حذف شود."
  echo "اگر خودکار حذف نشد:"
  echo "sudo rm -rf ${WEBROOT}/install"
}

main() {
  require_root
  detect_os
  ask_inputs
  install_packages
  deploy_source
  setup_apache
  setup_ssl
  final_message
}

main "$@"
