<?php
require_once __DIR__ . '/../app/Helpers.php';
require_once __DIR__ . '/../app/Database.php';
require_once __DIR__ . '/../app/Crypto.php';
require_once __DIR__ . '/../app/Telegram.php';

$root = dirname(__DIR__);
$configPath = $root . '/config.php';
$errors = [];

function detect_base_url(): string {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'example.com';
    $path = rtrim(str_replace('/install/index.php', '', $_SERVER['SCRIPT_NAME'] ?? ''), '/');
    return $scheme . '://' . $host . $path;
}

if (file_exists($configPath)) {
    $old = require $configPath;
    if (!empty($old['installed'])) {
        echo '<!doctype html><meta charset="utf-8"><body dir="rtl" style="font-family:tahoma;padding:30px"><h2>ربات قبلا نصب شده است.</h2><p>برای امنیت، پوشه install را حذف کنید.</p></body>';
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach (['pdo_sqlite','openssl','curl'] as $ext) if (!extension_loaded($ext)) $errors[] = "افزونه PHP لازم فعال نیست: $ext";
    $token = trim((string)($_POST['bot_token'] ?? ''));
    $adminId = (int)($_POST['admin_id'] ?? 0);
    $baseUrl = rtrim(trim((string)($_POST['base_url'] ?? detect_base_url())), '/');
    $botName = trim((string)($_POST['bot_name'] ?? ''));
    $panelPassword = (string)($_POST['panel_password'] ?? '');
    $merchant = trim((string)($_POST['zarinpal_merchant_id'] ?? ''));
    $sandbox = !empty($_POST['zarinpal_sandbox']);
    $authRequired = !empty($_POST['auth_required']);
    $gatewayZarinpal = !empty($_POST['gateway_zarinpal_enabled']);
    $gatewayCard = !empty($_POST['gateway_card_enabled']);
    $welcomeBonus = normalize_amount($_POST['welcome_bonus'] ?? 0);

    if (!preg_match('/^[0-9]{6,}:[A-Za-z0-9_\-]{20,}$/', $token)) $errors[] = 'توکن ربات معتبر نیست.';
    if ($adminId <= 0) $errors[] = 'آیدی عددی ادمین معتبر نیست.';
    if (strlen($panelPassword) < 8) $errors[] = 'رمز پنل مدیریت باید حداقل ۸ کاراکتر باشد.';
    if (!preg_match('#^https://#i', $baseUrl)) $errors[] = 'آدرس نصب باید HTTPS باشد.';

    if (!$errors) {
        try {
            $appKey = BotCrypto::newKey();
            $webhookSecret = bin2hex(random_bytes(32));
            $dbPath = $root . '/storage/bot.sqlite';
            $config = [
                'installed' => true,
                'debug' => false,
                'bot_token' => $token,
                'bot_username' => '',
                'bot_name' => $botName ?: 'کامفینگینو',
                'admin_id' => $adminId,
                'base_url' => $baseUrl,
                'webhook_secret' => $webhookSecret,
                'app_key' => $appKey,
                'db_path' => $dbPath,
                'zarinpal_merchant_id' => $merchant,
                'zarinpal_sandbox' => $sandbox,
                'currency' => 'IRT',
                'panel_password_hash' => password_hash($panelPassword, PASSWORD_DEFAULT),
            ];
            $tg = new TelegramClient($token);
            $me = $tg->call('getMe');
            if (empty($me['ok'])) throw new RuntimeException('توکن تلگرام تایید نشد: ' . ($me['description'] ?? 'unknown'));
            $config['bot_username'] = $me['result']['username'] ?? '';
            if ($botName === '') $config['bot_name'] = $me['result']['first_name'] ?? 'کامفینگینو';
            write_config_file($configPath, $config);

            $db = new BotDatabase($dbPath);
            $db->migrate();
            $db->seedDefaults([]);
            $db->setSetting('welcome_bonus', (string)$welcomeBonus);
            $db->setSetting('auth_required', $authRequired ? '1' : '0');
            $db->setSetting('gateway_zarinpal_enabled', $gatewayZarinpal ? '1' : '0');
            $db->setSetting('gateway_card_enabled', $gatewayCard ? '1' : '0');
            $db->setSetting('referral_enabled', '1');
            $db->setSetting('referral_reward_percent', '10');
            $db->setSetting('referral_signup_bonus', '0');
            $db->logSecurity('installer', 'system', 'install_success');

            $webhookUrl = $baseUrl . '/index.php';
            $set = $tg->call('setWebhook', [
                'url' => $webhookUrl,
                'secret_token' => $webhookSecret,
                'drop_pending_updates' => true,
                'allowed_updates' => json_encode(['message', 'callback_query']),
            ]);
            if (empty($set['ok'])) throw new RuntimeException('وبهوک ست نشد: ' . ($set['description'] ?? 'unknown'));
            $tg->sendMessage($adminId, "✅ نصب ربات با موفقیت انجام شد.\nوبهوک: $webhookUrl\nپنل وب: $baseUrl/admin/");
            @file_put_contents($root . '/storage/.htaccess', "Require all denied\nDeny from all\nOptions -Indexes\n");
            rrmdir_safe(__DIR__, $root);
            echo '<!doctype html><meta charset="utf-8"><body dir="rtl" style="font-family:tahoma;padding:30px"><h2>نصب کامل شد ✅</h2><p>پیام موفقیت برای ادمین ارسال شد. اگر پوشه install هنوز دیده می‌شود، دستی حذفش کنید.</p><p>آدرس پنل: <a href="../admin/">admin</a></p></body>';
            exit;
        } catch (Throwable $e) { $errors[] = $e->getMessage(); }
    }
}
$checks = ['pdo_sqlite'=>extension_loaded('pdo_sqlite'),'openssl'=>extension_loaded('openssl'),'curl'=>extension_loaded('curl'),'storage writable'=>is_writable($root . '/storage'),'root writable for config.php'=>is_writable($root)];
$base = detect_base_url();
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>نصب کامفینگینو</title><style>body{font-family:tahoma,Arial;background:#f6f7fb;margin:0;padding:24px;color:#111}.box{max-width:820px;margin:auto;background:#fff;border-radius:18px;padding:24px;box-shadow:0 10px 35px #0001}label{display:block;margin-top:14px;font-weight:bold}input{width:100%;box-sizing:border-box;padding:12px;border:1px solid #ddd;border-radius:12px;margin-top:6px}button{margin-top:18px;padding:13px 22px;border:0;border-radius:12px;background:#16a34a;color:#fff;font-weight:bold;cursor:pointer}.err{background:#fee2e2;color:#991b1b;padding:12px;border-radius:12px;margin:8px 0}.ok{color:#166534}.bad{color:#991b1b}.hint{background:#f1f5f9;padding:12px;border-radius:12px;line-height:1.9}</style></head><body><div class="box"><h1>نصب امن ربات فروش V2Ray</h1><div class="hint">بعد از نصب، دیتابیس SQLite ساخته می‌شود، کانفیگ‌ها با AES-256-GCM رمزنگاری می‌شوند، وبهوک با Secret Token ست می‌شود و پوشه install حذف خواهد شد.</div><h3>بررسی پیش‌نیازها</h3><ul><?php foreach ($checks as $k=>$v): ?><li class="<?= $v?'ok':'bad' ?>"><?= h($k) ?>: <?= $v?'OK':'FAILED' ?></li><?php endforeach; ?></ul><?php foreach ($errors as $e): ?><div class="err"><?= h($e) ?></div><?php endforeach; ?><form method="post" autocomplete="off"><label>توکن ربات تلگرام</label><input name="bot_token" required placeholder="123456:ABC..."><label>آیدی عددی ادمین</label><input name="admin_id" required inputmode="numeric" placeholder="123456789"><label>رمز پنل مدیریت وب</label><input type="password" name="panel_password" required minlength="8" placeholder="حداقل ۸ کاراکتر"><label>نام ربات</label><input name="bot_name" placeholder="مثلا کامفینگینو"><label>آدرس نصب HTTPS</label><input name="base_url" required value="<?= h($base) ?>"><label>مرچنت زرین‌پال</label><input name="zarinpal_merchant_id" placeholder="اختیاری؛ بعدا هم می‌توانید در config.php بگذارید"><label><input type="checkbox" name="zarinpal_sandbox" value="1" style="width:auto"> استفاده از Sandbox زرین‌پال</label><label><input type="checkbox" name="gateway_zarinpal_enabled" value="1" checked style="width:auto"> درگاه زرین‌پال فعال باشد</label><label><input type="checkbox" name="gateway_card_enabled" value="1" checked style="width:auto"> کارت به کارت فعال باشد</label><label><input type="checkbox" name="auth_required" value="1" style="width:auto"> احراز هویت شماره موبایل اجباری باشد</label><label>هدیه ورود اولیه کاربران</label><input name="welcome_bonus" inputmode="numeric" value="0"><button type="submit">نصب، ساخت دیتابیس، ست وبهوک و حذف install</button></form></div></body></html>
