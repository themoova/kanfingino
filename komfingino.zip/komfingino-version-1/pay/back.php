<?php
require_once __DIR__ . '/../app/Helpers.php';
require_once __DIR__ . '/../app/Database.php';
require_once __DIR__ . '/../app/Telegram.php';

$config = require __DIR__ . '/../config.php';
$db = new BotDatabase($config['db_path']);
$db->migrate();
$tg = new TelegramClient($config['bot_token']);
function pay_template(BotDatabase $db, string $key, array $vars = [], string $fallback = ''): string { return $db->renderTemplate($key, array_merge(['bot_name'=>'کامفینگینو'], $vars), $fallback); }
$gateway = strtolower(trim((string)($_GET['gw'] ?? 'zarinpal')));
if (!in_array($gateway, ['zarinpal','zibal'], true)) $gateway = 'zarinpal';

function post_json(string $url, array $payload): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_TIMEOUT => 30,
    ]);
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if ($raw === false) throw new RuntimeException('خطای ارتباط با درگاه: ' . $err);
    $json = json_decode($raw, true);
    if (!is_array($json)) throw new RuntimeException('پاسخ نامعتبر درگاه.');
    return [$json, $raw];
}

try {
    if ($gateway === 'zibal') {
        $trackId = (string)($_GET['trackId'] ?? '');
        $success = (string)($_GET['success'] ?? '');
        if ($trackId === '') throw new RuntimeException('شناسه تراکنش زیبال نامعتبر است.');
        $stmt = $db->pdo->prepare("SELECT * FROM payments WHERE authority=? AND gateway='zibal' ORDER BY id DESC LIMIT 1");
        $stmt->execute([$trackId]);
        $payment = $stmt->fetch();
        if (!$payment) throw new RuntimeException('پرداخت یافت نشد.');
        if ($success !== '1') {
            $stmt = $db->pdo->prepare("UPDATE payments SET status='cancelled' WHERE id=?");
            $stmt->execute([$payment['id']]);
            $db->logSecurity('payment_gateway', 'zibal', 'payment_cancelled', 'payment', $payment['id'], ['trackId'=>$trackId]);
            exit(pay_template($db, 'payment_failed', ['gateway'=>$gateway]));
        }
        $merchant = trim((string)$db->setting('zibal_merchant', ''));
        [$json, $raw] = post_json('https://gateway.zibal.ir/v1/verify', ['merchant'=>$merchant, 'trackId'=>$trackId]);
        if (($json['result'] ?? -1) !== 100) {
            $stmt = $db->pdo->prepare("UPDATE payments SET status='failed', meta=? WHERE id=?");
            $stmt->execute([$raw, $payment['id']]);
            $db->logSecurity('payment_gateway', 'zibal', 'payment_failed', 'payment', $payment['id'], ['trackId'=>$trackId]);
            exit(pay_template($db, 'payment_failed', ['gateway'=>'zibal']));
        }
        $refId = (string)($json['refNumber'] ?? $trackId);
        $db->pdo->exec('BEGIN IMMEDIATE');
        $stmt = $db->pdo->prepare('SELECT * FROM payments WHERE id=?');
        $stmt->execute([$payment['id']]);
        $payment = $stmt->fetch();
        if ($payment['status'] !== 'paid') {
            $stmt = $db->pdo->prepare("UPDATE payments SET status='paid', verified_at=?, ref_id=?, meta=? WHERE id=?");
            $stmt->execute([now_utc(), $refId, $raw, $payment['id']]);
            $stmt = $db->pdo->prepare('UPDATE users SET balance = balance + ?, updated_at=? WHERE id=?');
            $stmt->execute([(int)$payment['amount'], now_utc(), (int)$payment['user_id']]);
            $db->addUserTransaction((int)$payment['user_id'], (int)$payment['amount'], 'payment', 'zibal', 'zibal');
            $db->logSecurity('payment_gateway', 'zibal', 'payment_paid', 'payment', $payment['id'], ['amount'=>(int)$payment['amount'], 'ref_id'=>$refId]);
        }
        $db->pdo->commit();
        $stmt = $db->pdo->prepare('SELECT telegram_id,balance FROM users WHERE id=?');
        $stmt->execute([(int)$payment['user_id']]);
        $user = $stmt->fetch();
        if ($user) $tg->sendMessage((int)$user['telegram_id'], pay_template($db, 'payment_success', ['amount'=>number_format((int)$payment['amount']), 'ref_id'=>$refId, 'gateway'=>'zibal']));
        exit('پرداخت با موفقیت تایید شد. می‌توانید به ربات برگردید.');
    }

    $authority = (string)($_GET['Authority'] ?? '');
    $status = (string)($_GET['Status'] ?? '');
    if ($authority === '') throw new RuntimeException('Authority نامعتبر است.');
    $stmt = $db->pdo->prepare("SELECT * FROM payments WHERE authority=? AND gateway='zarinpal' ORDER BY id DESC LIMIT 1");
    $stmt->execute([$authority]);
    $payment = $stmt->fetch();
    if (!$payment) throw new RuntimeException('پرداخت یافت نشد.');
    if (strtoupper($status) !== 'OK') {
        $stmt = $db->pdo->prepare("UPDATE payments SET status='cancelled' WHERE id=?");
        $stmt->execute([$payment['id']]);
        $db->logSecurity('payment_gateway', 'zarinpal', 'payment_cancelled', 'payment', $payment['id'], ['authority'=>$authority]);
        exit(pay_template($db, 'payment_failed', ['gateway'=>$gateway]));
    }
    $merchant = trim((string)($config['zarinpal_merchant_id'] ?? ''));
    $endpoint = !empty($config['zarinpal_sandbox']) ? 'https://sandbox.zarinpal.com/pg/v4/payment/verify.json' : 'https://api.zarinpal.com/pg/v4/payment/verify.json';
    [$json, $raw] = post_json($endpoint, ['merchant_id'=>$merchant,'amount'=>(int)$payment['amount'],'authority'=>$authority]);
    $code = (int)($json['data']['code'] ?? 0);
    if (!in_array($code, [100, 101], true)) {
        $stmt = $db->pdo->prepare("UPDATE payments SET status='failed', meta=? WHERE id=?");
        $stmt->execute([$raw, $payment['id']]);
        $db->logSecurity('payment_gateway', 'zarinpal', 'payment_failed', 'payment', $payment['id'], ['authority'=>$authority]);
        exit(pay_template($db, 'payment_failed', ['gateway'=>'zarinpal']));
    }
    $refId = (string)($json['data']['ref_id'] ?? '');
    $db->pdo->exec('BEGIN IMMEDIATE');
    $stmt = $db->pdo->prepare('SELECT * FROM payments WHERE id=?');
    $stmt->execute([$payment['id']]);
    $payment = $stmt->fetch();
    if ($payment['status'] !== 'paid') {
        $stmt = $db->pdo->prepare("UPDATE payments SET status='paid', verified_at=?, ref_id=?, meta=? WHERE id=?");
        $stmt->execute([now_utc(), $refId, $raw, $payment['id']]);
        $stmt = $db->pdo->prepare('UPDATE users SET balance = balance + ?, updated_at=? WHERE id=?');
        $stmt->execute([(int)$payment['amount'], now_utc(), (int)$payment['user_id']]);
        $db->addUserTransaction((int)$payment['user_id'], (int)$payment['amount'], 'payment', 'zarinpal', 'zarinpal');
        $db->logSecurity('payment_gateway', 'zarinpal', 'payment_paid', 'payment', $payment['id'], ['amount'=>(int)$payment['amount'], 'ref_id'=>$refId]);
    }
    $db->pdo->commit();
    $stmt = $db->pdo->prepare('SELECT telegram_id,balance FROM users WHERE id=?');
    $stmt->execute([(int)$payment['user_id']]);
    $user = $stmt->fetch();
    if ($user) $tg->sendMessage((int)$user['telegram_id'], pay_template($db, 'payment_success', ['amount'=>number_format((int)$payment['amount']), 'ref_id'=>$refId, 'gateway'=>'zarinpal']));
    exit('پرداخت با موفقیت تایید شد. می‌توانید به ربات برگردید.');
} catch (Throwable $e) {
    if ($db->pdo->inTransaction()) $db->pdo->rollBack();
    http_response_code(500);
    echo 'خطا: ' . h($e->getMessage());
}
