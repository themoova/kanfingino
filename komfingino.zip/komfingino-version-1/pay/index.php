<?php
require_once __DIR__ . '/../app/Helpers.php';
require_once __DIR__ . '/../app/Database.php';
require_once __DIR__ . '/../app/Crypto.php';

$config = require __DIR__ . '/../config.php';
$db = new BotDatabase($config['db_path']);
$db->migrate();
$crypto = new BotCrypto($config['app_key']);

$telegramId = (int)($_GET['u'] ?? 0);
$amount = normalize_amount($_GET['a'] ?? 0);
$sig = (string)($_GET['s'] ?? '');
$gateway = strtolower(trim((string)($_GET['gw'] ?? 'zarinpal')));
if (!in_array($gateway, ['zarinpal','zibal'], true)) $gateway = 'zarinpal';
if ($telegramId <= 0 || $amount <= 0 || !$crypto->verify($telegramId . ':' . $amount, $sig)) {
    http_response_code(400); exit('لینک پرداخت نامعتبر است.');
}
$enabledSetting = $gateway === 'zibal' ? 'gateway_zibal_enabled' : 'gateway_zarinpal_enabled';
if ($db->setting($enabledSetting, $gateway === 'zibal' ? '0' : '1') !== '1') {
    http_response_code(403); exit('این درگاه غیرفعال است.');
}
$stmt = $db->pdo->prepare('SELECT * FROM users WHERE telegram_id=?');
$stmt->execute([$telegramId]);
$user = $stmt->fetch();
if (!$user) { http_response_code(404); exit('کاربر یافت نشد.'); }
$base = rtrim((string)$config['base_url'], '/');
$callback = $base . '/pay/back.php?gw=' . urlencode($gateway);
$desc = 'شارژ کیف پول کاربر ' . $telegramId;

function post_json(string $url, array $payload): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_TIMEOUT => 30,
    ]);
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    if ($raw === false) throw new RuntimeException('خطای ارتباط با درگاه: ' . $err);
    $json = json_decode($raw, true);
    if (!is_array($json)) throw new RuntimeException('پاسخ نامعتبر درگاه.');
    return [$json, $raw, $code];
}

try {
    if ($gateway === 'zibal') {
        $merchant = trim((string)$db->setting('zibal_merchant', ''));
        if ($merchant === '') throw new RuntimeException('مرچنت زیبال تنظیم نشده است.');
        [$json, $raw, $httpCode] = post_json('https://gateway.zibal.ir/v1/request', [
            'merchant' => $merchant,
            'amount' => $amount * 10,
            'callbackUrl' => $callback,
            'description' => $desc,
            'orderId' => (string)$telegramId,
            'mobile' => (string)($user['phone'] ?? ''),
        ]);
        if (($json['result'] ?? -1) !== 100) {
            throw new RuntimeException('خطا از زیبال: ' . ($json['message'] ?? 'نامشخص'));
        }
        $trackId = (string)$json['trackId'];
        $stmt = $db->pdo->prepare('INSERT INTO payments(user_id,amount,gateway,authority,status,created_at,meta) VALUES(?,?,?,?,?,?,?)');
        $stmt->execute([$user['id'], $amount, 'zibal', $trackId, 'pending', now_utc(), (string)$raw]);
        $db->logSecurity('user', $telegramId, 'payment_request', 'payment', $trackId, ['amount'=>$amount, 'gateway'=>'zibal']);
        header('Location: https://gateway.zibal.ir/start/' . urlencode($trackId));
        exit;
    }

    $merchant = trim((string)($config['zarinpal_merchant_id'] ?? ''));
    if ($merchant === '') throw new RuntimeException('مرچنت زرین‌پال تنظیم نشده است.');
    $endpoint = !empty($config['zarinpal_sandbox']) ? 'https://sandbox.zarinpal.com/pg/v4/payment/request.json' : 'https://api.zarinpal.com/pg/v4/payment/request.json';
    [$json, $raw, $httpCode] = post_json($endpoint, [
        'merchant_id' => $merchant,
        'amount' => $amount,
        'callback_url' => $callback,
        'description' => $desc,
        'metadata' => ['mobile' => (string)($user['phone'] ?? ''), 'email' => ''],
    ]);
    $authority = (string)($json['data']['authority'] ?? '');
    if ($authority === '') throw new RuntimeException('خطا از زرین‌پال.');
    $stmt = $db->pdo->prepare('INSERT INTO payments(user_id,amount,gateway,authority,status,created_at,meta) VALUES(?,?,?,?,?,?,?)');
    $stmt->execute([$user['id'], $amount, 'zarinpal', $authority, 'pending', now_utc(), (string)$raw]);
    $db->logSecurity('user', $telegramId, 'payment_request', 'payment', $authority, ['amount'=>$amount, 'gateway'=>'zarinpal']);
    $start = !empty($config['zarinpal_sandbox']) ? 'https://sandbox.zarinpal.com/pg/StartPay/' : 'https://www.zarinpal.com/pg/StartPay/';
    header('Location: ' . $start . urlencode($authority));
    exit;
} catch (Throwable $e) {
    http_response_code(500);
    echo 'خطا: ' . h($e->getMessage());
}
